// Simple export to avoid the need for the DashboardRenderingEngine
export { default as DashboardPlaceholder } from './DashboardPlaceholder';