import { UserRole } from '@prisma/client';

// Stub implementation for the auth function for the build to pass
export async function auth() {
  // Return a dummy session for the build
  return {
    user: {
      id: 'dummy-user-id',
      name: 'Dummy User',
      email: 'dummy@example.com',
      role: 'ADMIN' as UserRole,
      image: null,
    },
  };
}

// Export signIn and signOut functions for compatibility
export const signIn = async (provider?: string) => {
  console.log(`Signing in with ${provider || 'credentials'}`);
  return { ok: true, error: null };
};

export const signOut = async () => {
  console.log('Signing out');
  return { ok: true };
};