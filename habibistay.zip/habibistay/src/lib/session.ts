import { auth } from './auth';

// Stub implementation for the getCurrentUser function
export async function getCurrentUser() {
  const session = await auth();
  return session?.user || null;
}