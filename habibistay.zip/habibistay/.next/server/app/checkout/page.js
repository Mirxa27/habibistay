(() => {
var exports = {};
exports.id = 285;
exports.ids = [285];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 92761:
/***/ ((module) => {

"use strict";
module.exports = require("node:async_hooks");

/***/ }),

/***/ 17718:
/***/ ((module) => {

"use strict";
module.exports = require("node:child_process");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 15673:
/***/ ((module) => {

"use strict";
module.exports = require("node:events");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 93977:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 70612:
/***/ ((module) => {

"use strict";
module.exports = require("node:os");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 25997:
/***/ ((module) => {

"use strict";
module.exports = require("node:tty");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 34258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79346);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68365);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82934);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48520);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(88991);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87042);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(90140);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(75266);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79421);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(61920);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(49408);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57258);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(81745);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'checkout',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22136)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/checkout/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64337)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/checkout/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/checkout/page"
  

/***/ }),

/***/ 11945:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38135))

/***/ }),

/***/ 38135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ CheckoutPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ../node_modules/next/navigation.js
var navigation = __webpack_require__(52865);
// EXTERNAL MODULE: ../node_modules/next-auth/react.js + 2 modules
var react = __webpack_require__(27258);
// EXTERNAL MODULE: ./src/hooks/useBookings.ts
var useBookings = __webpack_require__(73999);
// EXTERNAL MODULE: ./src/hooks/usePayments.ts
var usePayments = __webpack_require__(26173);
// EXTERNAL MODULE: ../node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(35562);
;// CONCATENATED MODULE: ./src/hooks/useStripePayment.ts
/* __next_internal_client_entry_do_not_use__ useStripePayment auto */ 

function useStripePayment() {
    const [isLoading, setIsLoading] = (0,react_.useState)(false);
    const [error, setError] = (0,react_.useState)(null);
    const [paymentIntent, setPaymentIntent] = (0,react_.useState)(null);
    // Create a payment intent
    const createPaymentIntent = (0,react_.useCallback)(async ({ bookingId , amount , currency ="usd" , metadata ={}  })=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch("/api/payments/stripe", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    bookingId,
                    amount,
                    currency,
                    metadata
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to create payment intent");
            }
            const data = await response.json();
            setPaymentIntent(data);
            return data;
        } catch (error) {
            const message = error instanceof Error ? error.message : "Failed to create payment intent";
            setError(message);
            console.error("Error creating payment intent:", error);
            dist/* toast.error */.Am.error(message);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Process a payment with a payment method
    const processPayment = (0,react_.useCallback)(async ({ paymentIntentId , cardDetails  })=>{
        setIsLoading(true);
        setError(null);
        try {
            // In a real app, you would use Stripe.js to create a payment method and confirm the payment
            // Since we're mocking it, we'll just call our API directly
            // Create a mock payment method ID
            const paymentMethodId = `pm_${Math.random().toString(36).substring(2, 15)}`;
            // Confirm the payment intent
            const response = await fetch("/api/payments/stripe", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    paymentIntentId,
                    paymentMethodId
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to process payment");
            }
            const data = await response.json();
            setPaymentIntent(data);
            // Check payment intent status
            if (data.status === "succeeded") {
                dist/* toast.success */.Am.success("Payment processed successfully");
                return data;
            } else {
                throw new Error(`Payment failed with status: ${data.status}`);
            }
        } catch (error) {
            const message = error instanceof Error ? error.message : "Failed to process payment";
            setError(message);
            console.error("Error processing payment:", error);
            dist/* toast.error */.Am.error(message);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Check the status of a payment intent
    const checkPaymentStatus = (0,react_.useCallback)(async (paymentIntentId)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`/api/payments/stripe?paymentIntentId=${paymentIntentId}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to check payment status");
            }
            const data = await response.json();
            setPaymentIntent(data);
            return data;
        } catch (error) {
            const message = error instanceof Error ? error.message : "Failed to check payment status";
            setError(message);
            console.error("Error checking payment status:", error);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    return {
        isLoading,
        error,
        paymentIntent,
        createPaymentIntent,
        processPayment,
        checkPaymentStatus
    };
}

// EXTERNAL MODULE: ../node_modules/date-fns/index.js
var date_fns = __webpack_require__(58525);
// EXTERNAL MODULE: ./src/components/layout/MainLayout.tsx + 1 modules
var MainLayout = __webpack_require__(93514);
;// CONCATENATED MODULE: ./src/app/checkout/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









function CheckoutPage() {
    const router = (0,navigation.useRouter)();
    const searchParams = (0,navigation.useSearchParams)();
    const { status  } = (0,react/* useSession */.kP)(); // Simplified for build
    const { getBooking  } = (0,useBookings/* useBookings */.o)();
    const { getPayment  } = (0,usePayments/* usePayments */.I)();
    const { createPaymentIntent , processPayment  } = useStripePayment();
    // Get booking and payment IDs from URL
    const bookingId = searchParams.get("bookingId");
    const paymentId = searchParams.get("paymentId");
    const paymentIntentId = searchParams.get("paymentIntentId");
    // State
    const [isLoading, setIsLoading] = (0,react_.useState)(true);
    const [booking, setBooking] = (0,react_.useState)(null);
    const [payment, setPayment] = (0,react_.useState)(null);
    const [isProcessing, setIsProcessing] = (0,react_.useState)(false);
    const [paymentMethod, setPaymentMethod] = (0,react_.useState)("card");
    const [cardDetails, setCardDetails] = (0,react_.useState)({
        cardNumber: "",
        expiryDate: "",
        cvv: "",
        nameOnCard: ""
    });
    const [paymentIntent, setPaymentIntent] = (0,react_.useState)(null);
    // Check if user is authenticated
    (0,react_.useEffect)(()=>{
        if (status === "unauthenticated") {
            router.push("/login");
        }
    }, [
        status,
        router
    ]);
    // Load booking and payment details
    (0,react_.useEffect)(()=>{
        const loadData = async ()=>{
            if (!bookingId) {
                dist/* toast.error */.Am.error("Missing booking information");
                router.push("/");
                return;
            }
            setIsLoading(true);
            try {
                // Load booking details
                const bookingDetails = await getBooking(bookingId);
                if (bookingDetails) {
                    setBooking(bookingDetails);
                    // Check if we have an existing payment intent or need to create one
                    if (paymentIntentId) {
                        // If we have a payment intent ID in the URL, use that
                        setPaymentIntent({
                            id: paymentIntentId
                        });
                    } else if (paymentId) {
                        // If we have a payment ID, load payment details
                        const paymentDetails = await getPayment(paymentId);
                        if (paymentDetails) {
                            setPayment(paymentDetails);
                            // If payment has a transaction ID (Stripe payment intent), set it
                            if (paymentDetails.transactionId) {
                                setPaymentIntent({
                                    id: paymentDetails.transactionId
                                });
                            } else {
                                // Create a new payment intent
                                await initializePaymentIntent(bookingDetails);
                            }
                        } else {
                            dist/* toast.error */.Am.error("Failed to load payment details");
                            router.push("/");
                            return;
                        }
                    } else {
                        // No payment or payment intent yet, initialize one
                        await initializePaymentIntent(bookingDetails);
                    }
                } else {
                    dist/* toast.error */.Am.error("Failed to load booking details");
                    router.push("/");
                    return;
                }
            } catch (error) {
                console.error("Error loading data:", error);
                dist/* toast.error */.Am.error("An error occurred while loading your checkout information");
                router.push("/");
            } finally{
                setIsLoading(false);
            }
        };
        if (status === "authenticated") {
            loadData();
        }
    }, [
        bookingId,
        paymentId,
        paymentIntentId,
        getBooking,
        getPayment,
        router,
        status
    ]);
    // Initialize payment intent
    const initializePaymentIntent = async (bookingData)=>{
        try {
            // Create a payment intent with Stripe
            const intent = await createPaymentIntent({
                bookingId: bookingData.id,
                amount: bookingData.totalPrice,
                metadata: {
                    propertyId: bookingData.propertyId,
                    checkInDate: bookingData.checkInDate,
                    checkOutDate: bookingData.checkOutDate
                }
            });
            if (intent) {
                setPaymentIntent(intent);
                // Get payment details again now that we've created an intent
                if (paymentId) {
                    const updatedPayment = await getPayment(paymentId);
                    if (updatedPayment) {
                        setPayment(updatedPayment);
                    }
                }
            } else {
                throw new Error("Failed to create payment intent");
            }
        } catch (error) {
            console.error("Error initializing payment:", error);
            dist/* toast.error */.Am.error("Failed to initialize payment. Please try again later.");
        }
    };
    // Handle form input changes
    const handleInputChange = (e)=>{
        const { name , value  } = e.target;
        setCardDetails({
            ...cardDetails,
            [name]: value
        });
    };
    // Handle payment method change
    const handlePaymentMethodChange = (method)=>{
        setPaymentMethod(method);
    };
    // Handle form submission
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!paymentIntent || !booking) {
            dist/* toast.error */.Am.error("Missing payment information. Please refresh the page and try again.");
            return;
        }
        setIsProcessing(true);
        try {
            // Parse expiry date
            const [expMonth, expYear] = cardDetails.expiryDate.split("/");
            // Process payment with Stripe
            const result = await processPayment({
                paymentIntentId: paymentIntent.id,
                cardDetails: {
                    number: cardDetails.cardNumber.replace(/\s/g, ""),
                    exp_month: parseInt(expMonth, 10),
                    exp_year: parseInt(`20${expYear}`, 10),
                    cvc: cardDetails.cvv
                }
            });
            if (result) {
                dist/* toast.success */.Am.success("Payment successful! Redirecting to booking confirmation...");
                // Redirect to success page
                setTimeout(()=>{
                    router.push(`/bookings?success=true&bookingId=${booking.id}`);
                }, 2000);
            } else {
                dist/* toast.error */.Am.error("Payment failed. Please check your card details and try again.");
            }
        } catch (error) {
            console.error("Error processing payment:", error);
            dist/* toast.error */.Am.error("An error occurred while processing your payment");
        } finally{
            setIsProcessing(false);
        }
    };
    // Format booking dates
    const formatDate = (dateString)=>{
        return (0,date_fns.format)(new Date(dateString), "PPP");
    };
    if (isLoading) {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container mx-auto px-4 py-16",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "animate-pulse space-y-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-8 bg-gray-200 rounded w-1/3"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-4 bg-gray-200 rounded w-1/4"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-64 bg-gray-200 rounded"
                        })
                    ]
                })
            })
        });
    }
    if (!booking || !payment) {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto px-4 py-16",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl font-semibold mb-4",
                        children: "Checkout"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-gray-600",
                        children: "Unable to load checkout information. Please try again later."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "mt-4 bg-blue-600 text-white px-4 py-2 rounded-md",
                        onClick: ()=>router.push("/"),
                        children: "Return to Home"
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container mx-auto px-4 py-16",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-3xl font-semibold mb-4",
                    children: "Complete Your Booking"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 md:grid-cols-12 gap-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "md:col-span-7",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "bg-white rounded-lg shadow p-6",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-xl font-semibold mb-4",
                                        children: "Payment Information"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mb-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "font-medium mb-2",
                                                children: "Payment Method"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex space-x-4",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                        className: "flex items-center space-x-2 cursor-pointer",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                type: "radio",
                                                                name: "paymentMethod",
                                                                value: "card",
                                                                checked: paymentMethod === "card",
                                                                onChange: ()=>handlePaymentMethodChange("card"),
                                                                className: "h-4 w-4 text-blue-600"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: "Credit Card"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                        className: "flex items-center space-x-2 cursor-pointer",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                type: "radio",
                                                                name: "paymentMethod",
                                                                value: "paypal",
                                                                checked: paymentMethod === "paypal",
                                                                onChange: ()=>handlePaymentMethodChange("paypal"),
                                                                className: "h-4 w-4 text-blue-600"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: "PayPal"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    paymentMethod === "card" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                        onSubmit: handleSubmit,
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                                        children: "Card Number"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "text",
                                                        name: "cardNumber",
                                                        placeholder: "1234 5678 9012 3456",
                                                        className: "w-full p-2 border border-gray-300 rounded-md",
                                                        value: cardDetails.cardNumber,
                                                        onChange: handleInputChange,
                                                        disabled: isProcessing,
                                                        maxLength: 19,
                                                        pattern: "[0-9]{13,19}",
                                                        required: true
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "grid grid-cols-2 gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                                children: "Expiry Date"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                type: "text",
                                                                name: "expiryDate",
                                                                placeholder: "MM/YY",
                                                                className: "w-full p-2 border border-gray-300 rounded-md",
                                                                value: cardDetails.expiryDate,
                                                                onChange: handleInputChange,
                                                                disabled: isProcessing,
                                                                maxLength: 5,
                                                                pattern: "[0-9]{2}/[0-9]{2}",
                                                                required: true
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                                children: "CVV"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                type: "text",
                                                                name: "cvv",
                                                                placeholder: "123",
                                                                className: "w-full p-2 border border-gray-300 rounded-md",
                                                                value: cardDetails.cvv,
                                                                onChange: handleInputChange,
                                                                disabled: isProcessing,
                                                                maxLength: 4,
                                                                pattern: "[0-9]{3,4}",
                                                                required: true
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                                        children: "Name on Card"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "text",
                                                        name: "nameOnCard",
                                                        placeholder: "John Doe",
                                                        className: "w-full p-2 border border-gray-300 rounded-md",
                                                        value: cardDetails.nameOnCard,
                                                        onChange: handleInputChange,
                                                        disabled: isProcessing,
                                                        required: true
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                type: "submit",
                                                className: `w-full py-3 rounded-md font-medium text-white transition-colors ${isProcessing ? "bg-blue-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"}`,
                                                disabled: isProcessing,
                                                children: isProcessing ? "Processing..." : `Pay $${payment.amount}`
                                            })
                                        ]
                                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-gray-600",
                                                children: "You will be redirected to PayPal to complete your payment."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: handleSubmit,
                                                className: `w-full py-3 rounded-md font-medium text-white transition-colors ${isProcessing ? "bg-blue-400 cursor-not-allowed" : "bg-[#0070ba] hover:bg-[#003087]"}`,
                                                disabled: isProcessing,
                                                children: isProcessing ? "Processing..." : `Pay with PayPal`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mt-4 text-sm text-gray-500 text-center",
                                        children: "Your payment is secured with SSL encryption."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "md:col-span-5",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "bg-white rounded-lg shadow p-6 sticky top-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-xl font-semibold mb-4",
                                        children: "Booking Summary"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "font-medium",
                                                        children: booking.property?.title
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "text-gray-600 text-sm",
                                                        children: [
                                                            booking.property?.address,
                                                            ", ",
                                                            booking.property?.city,
                                                            ", ",
                                                            booking.property?.country
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "border-t border-b border-gray-100 py-4 grid grid-cols-2 gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-sm text-gray-500",
                                                                children: "Check-in"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "font-medium",
                                                                children: formatDate(booking.checkInDate)
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-sm text-gray-500",
                                                                children: "Check-out"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "font-medium",
                                                                children: formatDate(booking.checkOutDate)
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-sm text-gray-500",
                                                                children: "Guests"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "font-medium",
                                                                children: booking.numberOfGuests
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex justify-between",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "text-gray-600",
                                                                children: "Total"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "font-medium",
                                                                children: [
                                                                    "$",
                                                                    payment.amount
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex justify-between text-sm text-gray-500",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: "Status"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: payment.status
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 22136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63296);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/checkout/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 33533:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(49472)


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,4179,9633,9472,9658,5406,9091,153,3670,3999,6173], () => (__webpack_exec__(34258)));
module.exports = __webpack_exports__;

})();