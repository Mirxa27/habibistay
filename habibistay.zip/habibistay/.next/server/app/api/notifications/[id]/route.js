"use strict";
(() => {
var exports = {};
exports.id = 214;
exports.ids = [214];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 72163:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/notifications/[id]/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "DELETE": () => (DELETE),
  "PATCH": () => (PATCH)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./src/app/api/notifications/[id]/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());



// PATCH endpoint to mark a notification as read
async function PATCH(request, { params  }) {
    try {
        const notificationId = params.id;
        // Get user ID from the request headers
        const userId = request.headers.get("x-user-id");
        // Check if user is authenticated
        if (!userId) {
            return next_response["default"].json({
                error: "Unauthorized: Authentication required"
            }, {
                status: 401
            });
        }
        // Find notification
        const notification = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: notificationId
            }
        });
        // Check if notification exists
        if (!notification) {
            return next_response["default"].json({
                error: "Notification not found"
            }, {
                status: 404
            });
        }
        // Verify the notification belongs to the user
        if (notification.userId !== userId) {
            return next_response["default"].json({
                error: "Forbidden: You do not have permission to update this notification"
            }, {
                status: 403
            });
        }
        // Parse request body
        const body = await request.json();
        // Update the notification
        const updatedNotification = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: notificationId
            },
            data: {
                isRead: body.isRead !== undefined ? body.isRead : true
            }
        });
        return next_response["default"].json(updatedNotification);
    } catch (error) {
        console.error("Error updating notification:", error);
        return next_response["default"].json({
            error: "An error occurred while updating the notification"
        }, {
            status: 500
        });
    }
}
// DELETE endpoint to delete a notification
async function DELETE(request, { params  }) {
    try {
        const notificationId = params.id;
        // Get user ID and role from the request headers
        const userId = request.headers.get("x-user-id");
        const userRole = request.headers.get("x-user-role");
        // Check if user is authenticated
        if (!userId) {
            return next_response["default"].json({
                error: "Unauthorized: Authentication required"
            }, {
                status: 401
            });
        }
        // Find notification
        const notification = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: notificationId
            }
        });
        // Check if notification exists
        if (!notification) {
            return next_response["default"].json({
                error: "Notification not found"
            }, {
                status: 404
            });
        }
        // Verify the notification belongs to the user or user is admin
        if (notification.userId !== userId && userRole !== client_.UserRole.ADMIN) {
            return next_response["default"].json({
                error: "Forbidden: You do not have permission to delete this notification"
            }, {
                status: 403
            });
        }
        // Delete the notification
        await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: notificationId
            }
        });
        return next_response["default"].json({
            message: "Notification deleted successfully"
        }, {
            status: 200
        });
    } catch (error) {
        console.error("Error deleting notification:", error);
        return next_response["default"].json({
            error: "An error occurred while deleting the notification"
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fnotifications%2F%5Bid%5D%2Froute&name=app%2Fapi%2Fnotifications%2F%5Bid%5D%2Froute&pagePath=private-next-app-dir%2Fapi%2Fnotifications%2F%5Bid%5D%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fnotifications%2F%5Bid%5D%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/notifications/[id]",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/notifications/[id]/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/notifications/[id]/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(72163)));
module.exports = __webpack_exports__;

})();