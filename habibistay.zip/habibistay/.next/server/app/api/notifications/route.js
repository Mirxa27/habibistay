"use strict";
(() => {
var exports = {};
exports.id = 1996;
exports.ids = [1996];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 17873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/notifications/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "GET": () => (GET),
  "POST": () => (POST)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./src/app/api/notifications/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());



// GET endpoint to retrieve user notifications
async function GET(request) {
    try {
        // Get user ID from the request headers (set by middleware)
        const userId = request.headers.get("x-user-id");
        // Check if user is authenticated
        if (!userId) {
            return next_response["default"].json({
                error: "Unauthorized: Authentication required"
            }, {
                status: 401
            });
        }
        const { searchParams  } = new URL(request.url);
        // Parse query parameters
        const unreadOnly = searchParams.get("unreadOnly") === "true";
        const limit = searchParams.has("limit") ? parseInt(searchParams.get("limit"), 10) : 20;
        const page = searchParams.has("page") ? parseInt(searchParams.get("page"), 10) : 1;
        const skip = (page - 1) * limit;
        // Build filter conditions
        const where = {
            userId
        };
        if (unreadOnly) {
            where.isRead = false;
        }
        // Get total count for pagination
        const totalNotifications = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where
        });
        // Fetch notifications
        const notifications = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where,
            orderBy: {
                createdAt: "desc"
            },
            take: limit,
            skip
        });
        return next_response["default"].json({
            notifications,
            pagination: {
                total: totalNotifications,
                page,
                limit,
                pages: Math.ceil(totalNotifications / limit)
            }
        });
    } catch (error) {
        console.error("Error fetching notifications:", error);
        return next_response["default"].json({
            error: "An error occurred while fetching notifications"
        }, {
            status: 500
        });
    }
}
// POST endpoint to create a notification (admin only)
async function POST(request) {
    try {
        // Get user ID and role from the request headers
        const userId = request.headers.get("x-user-id");
        const userRole = request.headers.get("x-user-role");
        // Check if user is authenticated and has admin role
        if (!userId) {
            return next_response["default"].json({
                error: "Unauthorized: Authentication required"
            }, {
                status: 401
            });
        }
        if (userRole !== client_.UserRole.ADMIN) {
            return next_response["default"].json({
                error: "Forbidden: Admin access required"
            }, {
                status: 403
            });
        }
        // Parse the request body
        const body = await request.json();
        // Validate required fields
        const requiredFields = [
            "userId",
            "type",
            "title",
            "message"
        ];
        const missingFields = requiredFields.filter((field)=>!(field in body));
        if (missingFields.length > 0) {
            return next_response["default"].json({
                error: `Missing required fields: ${missingFields.join(", ")}`
            }, {
                status: 400
            });
        }
        // Check if target user exists
        const targetUser = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: body.userId
            },
            select: {
                id: true
            }
        });
        if (!targetUser) {
            return next_response["default"].json({
                error: "Target user not found"
            }, {
                status: 404
            });
        }
        // Create the notification
        const notification = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            data: {
                userId: body.userId,
                type: body.type,
                title: body.title,
                message: body.message,
                data: body.data ? JSON.stringify(body.data) : null,
                isRead: false
            }
        });
        return next_response["default"].json(notification, {
            status: 201
        });
    } catch (error) {
        console.error("Error creating notification:", error);
        return next_response["default"].json({
            error: "An error occurred while creating the notification"
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fnotifications%2Froute&name=app%2Fapi%2Fnotifications%2Froute&pagePath=private-next-app-dir%2Fapi%2Fnotifications%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fnotifications%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/notifications",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/notifications/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/notifications/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(17873)));
module.exports = __webpack_exports__;

})();