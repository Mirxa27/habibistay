"use strict";
(() => {
var exports = {};
exports.id = 2807;
exports.ids = [2807];
exports.modules = {

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 40235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/users/profile/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "GET": () => (GET),
  "PATCH": () => (PATCH)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
;// CONCATENATED MODULE: ./src/app/api/users/profile/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());

 // Assumes @/ maps to habibistay/src
async function GET(request) {
    try {
        // The middleware (from subtask 5.2) should have added user info to headers
        const userId = request.headers.get("x-user-id");
        if (!userId) {
            // This case should ideally be caught by the middleware if the route is protected
            return next_response["default"].json({
                error: "Unauthorized: User ID not found in request"
            }, {
                status: 401
            });
        }
        const user = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: userId
            },
            select: {
                id: true,
                name: true,
                email: true,
                emailVerified: true,
                image: true,
                role: true,
                phone: true,
                bio: true,
                address: true,
                city: true,
                country: true,
                createdAt: true,
                updatedAt: true,
                isInvestor: true
            }
        });
        if (!user) {
            return next_response["default"].json({
                error: "User not found"
            }, {
                status: 404
            });
        }
        return next_response["default"].json(user, {
            status: 200
        });
    } catch (error) {
        console.error("Get user profile error:", error);
        return next_response["default"].json({
            error: "An unexpected error occurred while fetching the profile."
        }, {
            status: 500
        });
    }
}
async function PATCH(request) {
    try {
        const userId = request.headers.get("x-user-id");
        if (!userId) {
            return next_response["default"].json({
                error: "Unauthorized: User ID not found in request"
            }, {
                status: 401
            });
        }
        const body = await request.json();
        const { name , phone , bio , address , city , country , image  } = body;
        // Construct a data object with only the fields that are provided in the request
        const dataToUpdate = {};
        if (name !== undefined) dataToUpdate.name = name;
        if (phone !== undefined) dataToUpdate.phone = phone;
        if (bio !== undefined) dataToUpdate.bio = bio;
        if (address !== undefined) dataToUpdate.address = address;
        if (city !== undefined) dataToUpdate.city = city;
        if (country !== undefined) dataToUpdate.country = country;
        if (image !== undefined) dataToUpdate.image = image; // Assuming image is a URL
        if (Object.keys(dataToUpdate).length === 0) {
            return next_response["default"].json({
                error: "No fields to update provided"
            }, {
                status: 400
            });
        }
        // Add basic validation if needed, e.g., for string lengths or formats
        // For example:
        // if (dataToUpdate.name && dataToUpdate.name.length > 100) {
        //   return NextResponse.json({ error: 'Name is too long' }, { status: 400 });
        // }
        const updatedUser = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: userId
            },
            data: dataToUpdate,
            select: {
                id: true,
                name: true,
                email: true,
                emailVerified: true,
                image: true,
                role: true,
                phone: true,
                bio: true,
                address: true,
                city: true,
                country: true,
                createdAt: true,
                updatedAt: true,
                isInvestor: true
            }
        });
        return next_response["default"].json(updatedUser, {
            status: 200
        });
    } catch (error) {
        console.error("Update user profile error:", error);
        // Check for specific Prisma errors, e.g., P2025 (Record to update not found)
        if (error instanceof Error && error.code === "P2025") {
            return next_response["default"].json({
                error: "User not found or concurrent update issue."
            }, {
                status: 404
            });
        }
        return next_response["default"].json({
            error: "An unexpected error occurred while updating the profile."
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fusers%2Fprofile%2Froute&name=app%2Fapi%2Fusers%2Fprofile%2Froute&pagePath=private-next-app-dir%2Fapi%2Fusers%2Fprofile%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fusers%2Fprofile%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/users/profile",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/users/profile/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/users/profile/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(40235)));
module.exports = __webpack_exports__;

})();