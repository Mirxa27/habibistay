"use strict";
(() => {
var exports = {};
exports.id = 3793;
exports.ids = [3793];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 99168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/host/analytics/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "GET": () => (GET)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: ../node_modules/date-fns/index.js
var date_fns = __webpack_require__(50882);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./src/app/api/host/analytics/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());




async function GET(request) {
    try {
        const userId = request.headers.get("x-user-id");
        if (!userId) {
            return next_response["default"].json({
                error: "Unauthorized: User ID not found in request"
            }, {
                status: 401
            });
        }
        // Get query parameters
        const searchParams = request.nextUrl.searchParams;
        const timeframeParam = searchParams.get("timeframe") || "last6Months";
        const propertyId = searchParams.get("propertyId");
        // Get analytics data
        const analyticsData = await generateAnalytics(userId, timeframeParam, propertyId);
        return next_response["default"].json(analyticsData, {
            status: 200
        });
    } catch (error) {
        console.error("Error fetching host analytics:", error);
        return next_response["default"].json({
            error: "An unexpected error occurred while fetching analytics."
        }, {
            status: 500
        });
    }
}
async function generateAnalytics(userId, timeframe, propertyId) {
    // Determine date range based on timeframe
    let startDate, endDate;
    const now = new Date();
    switch(timeframe){
        case "thisMonth":
            startDate = (0,date_fns.startOfMonth)(now);
            endDate = (0,date_fns.endOfMonth)(now);
            break;
        case "last3Months":
            startDate = (0,date_fns.startOfMonth)((0,date_fns.subMonths)(now, 2));
            endDate = (0,date_fns.endOfMonth)(now);
            break;
        case "last6Months":
            startDate = (0,date_fns.startOfMonth)((0,date_fns.subMonths)(now, 5));
            endDate = (0,date_fns.endOfMonth)(now);
            break;
        case "lastYear":
            startDate = (0,date_fns.startOfMonth)((0,date_fns.subMonths)(now, 11));
            endDate = (0,date_fns.endOfMonth)(now);
            break;
        default:
            startDate = (0,date_fns.startOfMonth)((0,date_fns.subMonths)(now, 5));
            endDate = (0,date_fns.endOfMonth)(now);
    }
    // Base query conditions for properties owned by this host
    const whereConditions = {
        userId
    };
    // Add property filter if specified
    if (propertyId) {
        whereConditions.id = propertyId;
    }
    // Get host properties
    const properties = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
        where: whereConditions,
        select: {
            id: true,
            title: true
        }
    });
    const propertyIds = properties.map((property)=>property.id);
    // Query total bookings and revenue
    const bookings = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
        where: {
            propertyId: {
                in: propertyIds
            },
            createdAt: {
                gte: startDate,
                lte: endDate
            }
        },
        include: {
            payments: true,
            property: {
                select: {
                    id: true,
                    title: true
                }
            }
        }
    });
    // Calculate monthly revenue and bookings
    const monthlyData = {};
    // Initialize months in the range
    let currentDate = new Date(startDate);
    while(currentDate <= endDate){
        const monthKey = (0,date_fns.format)(currentDate, "MMM yyyy");
        monthlyData[monthKey] = {
            revenue: 0,
            bookings: 0
        };
        currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1);
    }
    // Fill in the actual data
    bookings.forEach((booking)=>{
        const monthKey = (0,date_fns.format)(new Date(booking.createdAt), "MMM yyyy");
        // Count all bookings
        monthlyData[monthKey].bookings += 1;
        // Only count revenue from completed or confirmed bookings with successful payments
        const successfulPayment = booking.payments.some((payment)=>payment.status === client_.PaymentStatus.COMPLETED);
        if ((booking.status === client_.BookingStatus.CONFIRMED || booking.status === client_.BookingStatus.COMPLETED) && successfulPayment) {
            monthlyData[monthKey].revenue += Number(booking.totalPrice);
        }
    });
    // Calculate booking status breakdown
    const bookingStatusCounts = {
        [client_.BookingStatus.PENDING]: 0,
        [client_.BookingStatus.CONFIRMED]: 0,
        [client_.BookingStatus.COMPLETED]: 0,
        [client_.BookingStatus.CANCELLED]: 0,
        [client_.BookingStatus.REJECTED]: 0
    };
    bookings.forEach((booking)=>{
        bookingStatusCounts[booking.status] += 1;
    });
    // Calculate property performance
    const propertyPerformance = propertyIds.map((propId)=>{
        const propertyBookings = bookings.filter((booking)=>booking.propertyId === propId);
        const propertyRevenue = propertyBookings.filter((booking)=>(booking.status === client_.BookingStatus.CONFIRMED || booking.status === client_.BookingStatus.COMPLETED) && booking.payments.some((payment)=>payment.status === client_.PaymentStatus.COMPLETED)).reduce((sum, booking)=>sum + Number(booking.totalPrice), 0);
        const property = properties.find((p)=>p.id === propId);
        return {
            id: propId,
            title: property?.title || "Unknown Property",
            bookings: propertyBookings.length,
            revenue: propertyRevenue,
            occupancyRate: calculateOccupancyRate(propertyBookings, startDate, endDate)
        };
    }).sort((a, b)=>b.revenue - a.revenue); // Sort by revenue, highest first
    // Calculate overall stats
    const totalBookings = bookings.length;
    const totalRevenue = bookings.filter((booking)=>(booking.status === client_.BookingStatus.CONFIRMED || booking.status === client_.BookingStatus.COMPLETED) && booking.payments.some((payment)=>payment.status === client_.PaymentStatus.COMPLETED)).reduce((sum, booking)=>sum + Number(booking.totalPrice), 0);
    const confirmedBookings = bookings.filter((booking)=>booking.status === client_.BookingStatus.CONFIRMED || booking.status === client_.BookingStatus.COMPLETED).length;
    const averageBookingValue = totalBookings > 0 ? totalRevenue / confirmedBookings : 0;
    return {
        summary: {
            totalBookings,
            totalRevenue,
            confirmedBookings,
            cancelledBookings: bookingStatusCounts[client_.BookingStatus.CANCELLED],
            averageBookingValue,
            occupancyRate: calculateAverageOccupancyRate(bookings, propertyIds.length, startDate, endDate)
        },
        monthlyData: Object.entries(monthlyData).map(([month, data])=>({
                month,
                ...data
            })),
        bookingStatusBreakdown: bookingStatusCounts,
        propertyPerformance,
        dateRange: {
            startDate: startDate.toISOString(),
            endDate: endDate.toISOString()
        }
    };
}
// Helper function to calculate occupancy rate for a single property
function calculateOccupancyRate(bookings, startDate, endDate) {
    // This is a simplified calculation - in a real system you'd consider actual day-by-day availability
    const confirmedBookings = bookings.filter((booking)=>booking.status === client_.BookingStatus.CONFIRMED || booking.status === client_.BookingStatus.COMPLETED);
    if (confirmedBookings.length === 0) return 0;
    // Calculate total nights booked
    let totalNightsBooked = 0;
    confirmedBookings.forEach((booking)=>{
        const checkIn = new Date(booking.checkInDate);
        const checkOut = new Date(booking.checkOutDate);
        // Get number of nights
        const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
        totalNightsBooked += nights;
    });
    // Calculate total available nights in the period
    const totalDaysInPeriod = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    // Cap at 100% since our simplified calculation might exceed that in some cases
    return Math.min(100, totalNightsBooked / totalDaysInPeriod * 100);
}
// Helper function to calculate average occupancy rate across all properties
function calculateAverageOccupancyRate(bookings, propertyCount, startDate, endDate) {
    if (propertyCount === 0) return 0;
    const occupancyRate = calculateOccupancyRate(bookings, startDate, endDate);
    return occupancyRate / propertyCount;
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fhost%2Fanalytics%2Froute&name=app%2Fapi%2Fhost%2Fanalytics%2Froute&pagePath=private-next-app-dir%2Fapi%2Fhost%2Fanalytics%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fhost%2Fanalytics%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/host/analytics",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/host/analytics/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/host/analytics/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706,882], () => (__webpack_exec__(99168)));
module.exports = __webpack_exports__;

})();