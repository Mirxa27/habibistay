"use strict";
(() => {
var exports = {};
exports.id = 1248;
exports.ids = [1248];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 68713:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/properties/[id]/images/[imageId]/set-primary/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "PATCH": () => (PATCH)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./src/app/api/properties/[id]/images/[imageId]/set-primary/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());




/**
 * PATCH /api/properties/[id]/images/[imageId]/set-primary
 * Set an image as the primary image for a property
 */ async function PATCH(_request, { params  }) {
    try {
        const { id: propertyId , imageId  } = params;
        // 1. Get the current user session
        const session = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())();
        if (!session?.user) {
            return next_response["default"].json({
                error: "You must be logged in to update images"
            }, {
                status: 401
            });
        }
        // 2. Check if the property exists and user has permission
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: propertyId
            },
            select: {
                id: true,
                ownerId: true,
                managers: {
                    where: {
                        managerId: session.user.id
                    },
                    select: {
                        id: true
                    }
                },
                images: {
                    where: {
                        id: imageId
                    },
                    select: {
                        id: true
                    }
                }
            }
        });
        if (!property) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // Check if the image exists and belongs to this property
        const imageToSetAsPrimary = property.images[0];
        if (!imageToSetAsPrimary) {
            return next_response["default"].json({
                error: "Image not found"
            }, {
                status: 404
            });
        }
        // Check if user is the owner, a manager, or an admin
        const isOwner = property.ownerId === session.user.id;
        const isManager = property.managers.length > 0;
        const isAdmin = session.user.role === client_.UserRole.ADMIN;
        if (!isOwner && !isManager && !isAdmin) {
            return next_response["default"].json({
                error: "You do not have permission to update images for this property"
            }, {
                status: 403
            });
        }
        // 3. Start a transaction to update the images
        const [_, updatedImage] = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())([
            // Set all other images as not primary
            Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                where: {
                    propertyId,
                    isPrimary: true,
                    id: {
                        not: imageId
                    }
                },
                data: {
                    isPrimary: false
                }
            }),
            // Set the requested image as primary
            Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                where: {
                    id: imageId
                },
                data: {
                    isPrimary: true
                },
                select: {
                    id: true,
                    url: true,
                    secureUrl: true,
                    isPrimary: true
                }
            })
        ]);
        return next_response["default"].json({
            message: "Primary image updated successfully",
            data: updatedImage
        });
    } catch (error) {
        console.error("Error setting primary image:", error);
        return next_response["default"].json({
            error: "An error occurred while setting the primary image"
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Fset-primary%2Froute&name=app%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Fset-primary%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Fset-primary%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Fset-primary%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/properties/[id]/images/[imageId]/set-primary",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/properties/[id]/images/[imageId]/set-primary/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/properties/[id]/images/[imageId]/set-primary/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(68713)));
module.exports = __webpack_exports__;

})();