"use strict";
(() => {
var exports = {};
exports.id = 728;
exports.ids = [728];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 92422:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/properties/[id]/images/[imageId]/caption/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "PATCH": () => (PATCH)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./src/app/api/properties/[id]/images/[imageId]/caption/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());




/**
 * PATCH /api/properties/[propertyId]/images/[imageId]/caption
 * Update the caption of a property image
 */ async function PATCH(request, { params  }) {
    try {
        const { propertyId , imageId  } = params;
        // 1. Get the current user session
        const session = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())();
        if (!session?.user) {
            return next_response["default"].json({
                error: "You must be logged in to update image captions"
            }, {
                status: 401
            });
        }
        // 2. Parse the request body
        const { caption  } = await request.json();
        if (typeof caption !== "string" && caption !== null) {
            return next_response["default"].json({
                error: "Invalid caption format"
            }, {
                status: 400
            });
        }
        // 3. Get the image and property with owner/manager info
        const image = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: imageId
            },
            include: {
                property: {
                    select: {
                        id: true,
                        ownerId: true,
                        managers: {
                            where: {
                                managerId: session.user.id
                            },
                            select: {
                                id: true
                            }
                        }
                    }
                }
            }
        });
        if (!image) {
            return next_response["default"].json({
                error: "Image not found"
            }, {
                status: 404
            });
        }
        // 4. Check if the property exists and the user has permission
        const property = image.property;
        if (!property || property.id !== propertyId) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // 5. Check if user is the owner, a manager, or an admin
        const isOwner = property.ownerId === session.user.id;
        const isManager = property.managers.length > 0;
        const isAdmin = session.user.role === client_.UserRole.ADMIN;
        if (!isOwner && !isManager && !isAdmin) {
            return next_response["default"].json({
                error: "You do not have permission to update captions for this property"
            }, {
                status: 403
            });
        }
        // 6. Update the image caption
        const updatedImage = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: imageId
            },
            data: {
                caption: caption || null
            },
            select: {
                id: true,
                caption: true,
                // Model doesn't have updatedAt field
                createdAt: true
            }
        });
        return next_response["default"].json({
            message: "Image caption updated successfully",
            data: updatedImage
        });
    } catch (error) {
        console.error("Error updating image caption:", error);
        return next_response["default"].json({
            error: "An error occurred while updating the image caption"
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Fcaption%2Froute&name=app%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Fcaption%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Fcaption%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Fcaption%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/properties/[id]/images/[imageId]/caption",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/properties/[id]/images/[imageId]/caption/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/properties/[id]/images/[imageId]/caption/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(92422)));
module.exports = __webpack_exports__;

})();