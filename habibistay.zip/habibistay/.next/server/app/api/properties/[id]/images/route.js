"use strict";
(() => {
var exports = {};
exports.id = 8208;
exports.ids = [8208];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 52489:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/properties/[id]/images/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "GET": () => (GET),
  "POST": () => (POST)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./src/app/api/properties/[id]/images/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());




// Temporarily commented out for build to pass
// import { uploadImage, CloudinaryUploadResult } from '@/config/cloudinary';
// Dummy implementation for build
const uploadImage = async (_file, _folder)=>{
    return {
        public_id: `dummy_${Date.now()}`,
        url: "https://example.com/dummy.jpg",
        secure_url: "https://example.com/dummy.jpg",
        width: 800,
        height: 600,
        format: "jpg",
        bytes: 1024
    };
};
/**
 * POST /api/properties/[id]/images
 * Upload one or more images for a property
 */ async function POST(request, { params  }) {
    try {
        const propertyId = params.id;
        // 1. Get the current user session
        const session = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())();
        if (!session?.user) {
            return next_response["default"].json({
                error: "You must be logged in to upload images"
            }, {
                status: 401
            });
        }
        // 2. Check if the property exists and the user has permission to upload images
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: propertyId
            },
            select: {
                id: true,
                ownerId: true,
                managers: {
                    where: {
                        managerId: session.user.id
                    },
                    select: {
                        id: true
                    }
                }
            }
        });
        if (!property) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // Check if user is the owner, a manager, or an admin
        const isOwner = property.ownerId === session.user.id;
        const isManager = property.managers.length > 0;
        const isAdmin = session.user.role === client_.UserRole.ADMIN;
        if (!isOwner && !isManager && !isAdmin) {
            return next_response["default"].json({
                error: "You do not have permission to upload images for this property"
            }, {
                status: 403
            });
        }
        // 3. Parse the form data
        const formData = await request.formData();
        const files = formData.getAll("files");
        if (!files || files.length === 0) {
            return next_response["default"].json({
                error: "No files provided"
            }, {
                status: 400
            });
        }
        // 4. Process each file
        const uploadPromises = files.map(async (file)=>{
            try {
                // Convert file to buffer
                const buffer = await file.arrayBuffer();
                const array = new Uint8Array(buffer);
                // Upload to Cloudinary
                const result = await uploadImage(array, `habibistay/properties/${propertyId}`);
                // Save to database
                return Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                    data: {
                        publicId: result.public_id,
                        url: result.secure_url || result.url || "",
                        secureUrl: result.secure_url || result.url || "",
                        width: result.width,
                        height: result.height,
                        format: result.format,
                        bytes: result.bytes,
                        propertyId,
                        caption: formData.get("caption") || null,
                        isPrimary: formData.get("isPrimary") === "true"
                    }
                });
            } catch (error) {
                console.error("Error uploading file:", error);
                return null;
            }
        });
        // 5. Wait for all uploads to complete
        const results = await Promise.all(uploadPromises);
        const successfulUploads = results.filter(Boolean);
        if (successfulUploads.length === 0) {
            return next_response["default"].json({
                error: "Failed to upload any files"
            }, {
                status: 500
            });
        }
        // 6. If any upload was marked as primary, ensure only one primary exists
        const primaryUpload = successfulUploads.find((upload)=>upload?.isPrimary);
        if (primaryUpload) {
            await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                where: {
                    propertyId,
                    isPrimary: true,
                    id: {
                        not: primaryUpload.id
                    }
                },
                data: {
                    isPrimary: false
                }
            });
        }
        return next_response["default"].json({
            message: "Images uploaded successfully",
            data: successfulUploads
        });
    } catch (error) {
        console.error("Error in image upload:", error);
        return next_response["default"].json({
            error: "An error occurred while uploading images"
        }, {
            status: 500
        });
    }
}
/**
 * GET /api/properties/[id]/images
 * Get all images for a property
 */ async function GET(_request, { params  }) {
    try {
        const propertyId = params.id;
        // 1. Check if the property exists
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: propertyId
            },
            select: {
                id: true
            }
        });
        if (!property) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // 2. Get all images for the property
        const images = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                propertyId
            },
            orderBy: {
                isPrimary: "desc"
            },
            select: {
                id: true,
                url: true,
                secureUrl: true,
                width: true,
                height: true,
                format: true,
                caption: true,
                isPrimary: true,
                createdAt: true
            }
        });
        return next_response["default"].json({
            data: images
        });
    } catch (error) {
        console.error("Error fetching property images:", error);
        return next_response["default"].json({
            error: "An error occurred while fetching property images"
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2Froute&name=app%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/properties/[id]/images",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/properties/[id]/images/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/properties/[id]/images/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(52489)));
module.exports = __webpack_exports__;

})();