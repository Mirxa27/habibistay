"use strict";
(() => {
var exports = {};
exports.id = 9891;
exports.ids = [9891];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 96034:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/properties/[id]/availability/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "GET": () => (GET),
  "POST": () => (POST)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./src/app/api/properties/[id]/availability/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());



async function POST(request, { params  }) {
    try {
        const propertyId = params.id;
        // Get user ID and role from the request headers
        const userId = request.headers.get("x-user-id");
        const userRole = request.headers.get("x-user-role");
        // Check if user is authenticated
        if (!userId) {
            return next_response["default"].json({
                error: "Unauthorized: Authentication required"
            }, {
                status: 401
            });
        }
        // Fetch the property to check ownership
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: propertyId
            },
            include: {
                managers: {
                    select: {
                        managerId: true
                    }
                }
            }
        });
        if (!property) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // Check if user is the property owner, a manager, or an admin
        const isOwner = property.ownerId === userId;
        const isManager = property.managers.some((m)=>m.managerId === userId);
        const isAdmin = userRole === client_.UserRole.ADMIN;
        if (!isOwner && !isManager && !isAdmin) {
            return next_response["default"].json({
                error: "Forbidden: You do not have permission to update this property's availability"
            }, {
                status: 403
            });
        }
        // Parse the request body
        const body = await request.json();
        // Validate request body
        if (!body.dates || !Array.isArray(body.dates) || body.dates.length === 0) {
            return next_response["default"].json({
                error: "Invalid request: dates array is required and cannot be empty"
            }, {
                status: 400
            });
        }
        // Process each date entry
        const results = await Promise.all(body.dates.map(async (dateEntry)=>{
            // Validate date format
            const date = new Date(dateEntry.date);
            if (isNaN(date.getTime())) {
                return {
                    date: dateEntry.date,
                    status: "error",
                    message: "Invalid date format"
                };
            }
            // Set time to midnight for consistent handling
            date.setHours(0, 0, 0, 0);
            try {
                // Note: We're using upsert below, so no need to check for existing record separately
                // We'll skip this check to pass the build
                // Check if there are any bookings for this date
                const conflictingBookings = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                    where: {
                        propertyId,
                        status: {
                            in: [
                                "PENDING",
                                "CONFIRMED"
                            ]
                        },
                        checkInDate: {
                            lte: date
                        },
                        checkOutDate: {
                            gt: date
                        }
                    }
                });
                // If we're marking as unavailable and there are bookings, return an error
                if (!dateEntry.isAvailable && conflictingBookings.length > 0) {
                    return {
                        date: dateEntry.date,
                        status: "error",
                        message: "Cannot mark as unavailable: date has existing bookings"
                    };
                }
                // Prepare data for upsert
                const availabilityData = {
                    propertyId,
                    date,
                    isAvailable: dateEntry.isAvailable,
                    price: dateEntry.price !== undefined ? dateEntry.price : undefined
                };
                // Update or create the availability record
                const availability = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                    where: {
                        propertyId_date: {
                            propertyId,
                            date
                        }
                    },
                    update: {
                        isAvailable: dateEntry.isAvailable,
                        price: dateEntry.price !== undefined ? dateEntry.price : undefined
                    },
                    create: availabilityData
                });
                return {
                    date: dateEntry.date,
                    status: "success",
                    availability
                };
            } catch (error) {
                console.error(`Error updating availability for ${dateEntry.date}:`, error);
                return {
                    date: dateEntry.date,
                    status: "error",
                    message: "Database error while updating availability"
                };
            }
        }));
        return next_response["default"].json({
            results
        });
    } catch (error) {
        console.error("Error updating property availability:", error);
        return next_response["default"].json({
            error: "An error occurred while updating property availability"
        }, {
            status: 500
        });
    }
}
async function GET(request, { params  }) {
    try {
        const propertyId = params.id;
        const { searchParams  } = new URL(request.url);
        // Parse query parameters
        const startDateParam = searchParams.get("startDate");
        const endDateParam = searchParams.get("endDate");
        // Validate date parameters
        if (!startDateParam || !endDateParam) {
            return next_response["default"].json({
                error: "Both startDate and endDate parameters are required"
            }, {
                status: 400
            });
        }
        const startDate = new Date(startDateParam);
        const endDate = new Date(endDateParam);
        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
            return next_response["default"].json({
                error: "Invalid date format. Use ISO date strings (YYYY-MM-DD)"
            }, {
                status: 400
            });
        }
        if (startDate >= endDate) {
            return next_response["default"].json({
                error: "End date must be after start date"
            }, {
                status: 400
            });
        }
        // Check if property exists
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: propertyId
            },
            select: {
                id: true,
                price: true
            }
        });
        if (!property) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // Get availability records for the date range
        const availabilityRecords = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                propertyId,
                date: {
                    gte: startDate,
                    lt: endDate
                }
            },
            orderBy: {
                date: "asc"
            }
        });
        // Get bookings for the date range to check conflicts
        const bookings = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                propertyId,
                status: {
                    in: [
                        "PENDING",
                        "CONFIRMED"
                    ]
                },
                OR: [
                    {
                        checkInDate: {
                            lte: endDate
                        },
                        checkOutDate: {
                            gt: startDate
                        }
                    }
                ]
            },
            select: {
                id: true,
                checkInDate: true,
                checkOutDate: true,
                status: true
            }
        });
        // Create a map of dates with booking information
        const bookedDatesMap = new Map();
        bookings.forEach((booking)=>{
            const checkIn = new Date(booking.checkInDate);
            const checkOut = new Date(booking.checkOutDate);
            // Iterate through each day of the booking
            const currentDate = new Date(checkIn);
            while(currentDate < checkOut){
                const dateStr = currentDate.toISOString().split("T")[0];
                bookedDatesMap.set(dateStr, booking.id);
                // Move to next day
                currentDate.setDate(currentDate.getDate() + 1);
            }
        });
        // Create a map of dates with availability information
        const availabilityMap = new Map();
        availabilityRecords.forEach((record)=>{
            const dateStr = record.date.toISOString().split("T")[0];
            availabilityMap.set(dateStr, record);
        });
        // Generate the full date range with availability info
        const result = [];
        const currentDate = new Date(startDate);
        while(currentDate < endDate){
            const dateStr = currentDate.toISOString().split("T")[0];
            const availabilityRecord = availabilityMap.get(dateStr);
            const bookingId = bookedDatesMap.get(dateStr);
            result.push({
                date: dateStr,
                isAvailable: availabilityRecord ? availabilityRecord.isAvailable : true,
                price: availabilityRecord?.price || property.price,
                isBooked: bookingId ? true : false,
                bookingId: bookingId || null
            });
            // Move to next day
            currentDate.setDate(currentDate.getDate() + 1);
        }
        return next_response["default"].json({
            propertyId,
            startDate: startDateParam,
            endDate: endDateParam,
            basePrice: property.price,
            availability: result
        });
    } catch (error) {
        console.error("Error fetching property availability:", error);
        return next_response["default"].json({
            error: "An error occurred while fetching property availability"
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fproperties%2F%5Bid%5D%2Favailability%2Froute&name=app%2Fapi%2Fproperties%2F%5Bid%5D%2Favailability%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproperties%2F%5Bid%5D%2Favailability%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fproperties%2F%5Bid%5D%2Favailability%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/properties/[id]/availability",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/properties/[id]/availability/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/properties/[id]/availability/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(96034)));
module.exports = __webpack_exports__;

})();