"use strict";
(() => {
var exports = {};
exports.id = 3633;
exports.ids = [3633];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 42311:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/properties/[id]/images/[imageId]/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "DELETE": () => (DELETE),
  "GET": () => (GET),
  "PATCH": () => (PATCH)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
;// CONCATENATED MODULE: ./src/app/api/properties/[id]/images/[imageId]/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());




// Temporarily commenting out missing import for build to pass
// import { deleteImage } from '@/config/cloudinary';
/**
 * GET /api/properties/[id]/images/[imageId]
 * Get a specific image by ID
 */ async function GET(_request, { params  }) {
    try {
        const { id: propertyId , imageId  } = params;
        // 1. Check if the property exists
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: propertyId
            },
            select: {
                id: true
            }
        });
        if (!property) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // 2. Get the image
        const image = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: imageId
            },
            select: {
                id: true,
                publicId: true,
                url: true,
                secureUrl: true,
                width: true,
                height: true,
                format: true,
                bytes: true,
                caption: true,
                isPrimary: true,
                createdAt: true,
                propertyId: true
            }
        });
        if (!image || image.propertyId !== propertyId) {
            return next_response["default"].json({
                error: "Image not found"
            }, {
                status: 404
            });
        }
        return next_response["default"].json({
            data: image
        });
    } catch (error) {
        console.error("Error fetching image:", error);
        return next_response["default"].json({
            error: "An error occurred while fetching the image"
        }, {
            status: 500
        });
    }
}
/**
 * PATCH /api/properties/[id]/images/[imageId]
 * Update an image (e.g., set as primary, update caption)
 */ async function PATCH(request, { params  }) {
    try {
        const { id: propertyId , imageId  } = params;
        const body = await request.json();
        // 1. Get the current user session
        const session = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())();
        if (!session?.user) {
            return next_response["default"].json({
                error: "You must be logged in to update images"
            }, {
                status: 401
            });
        }
        // 2. Check if the property exists and user has permission
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: propertyId
            },
            select: {
                id: true,
                ownerId: true,
                managers: {
                    where: {
                        managerId: session.user.id
                    },
                    select: {
                        id: true
                    }
                }
            }
        });
        if (!property) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // Check if user is the owner, a manager, or an admin
        const isOwner = property.ownerId === session.user.id;
        const isManager = property.managers.length > 0;
        const isAdmin = session.user.role === client_.UserRole.ADMIN;
        if (!isOwner && !isManager && !isAdmin) {
            return next_response["default"].json({
                error: "You do not have permission to update images for this property"
            }, {
                status: 403
            });
        }
        // 3. Check if the image exists and belongs to this property
        const existingImage = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: imageId
            },
            select: {
                id: true,
                propertyId: true,
                isPrimary: true
            }
        });
        if (!existingImage || existingImage.propertyId !== propertyId) {
            return next_response["default"].json({
                error: "Image not found"
            }, {
                status: 404
            });
        }
        // 4. Prepare update data
        const updateData = {};
        if (body.caption !== undefined) {
            updateData.caption = body.caption || null;
        }
        if (body.isPrimary !== undefined) {
            updateData.isPrimary = Boolean(body.isPrimary);
            // If setting as primary, ensure no other images are marked as primary
            if (updateData.isPrimary) {
                await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                    where: {
                        propertyId,
                        isPrimary: true,
                        id: {
                            not: imageId
                        }
                    },
                    data: {
                        isPrimary: false
                    }
                });
            }
        }
        // 5. Update the image
        const updatedImage = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: imageId
            },
            data: updateData,
            select: {
                id: true,
                url: true,
                secureUrl: true,
                caption: true,
                isPrimary: true
            }
        });
        return next_response["default"].json({
            message: "Image updated successfully",
            data: updatedImage
        });
    } catch (error) {
        console.error("Error updating image:", error);
        return next_response["default"].json({
            error: "An error occurred while updating the image"
        }, {
            status: 500
        });
    }
}
/**
 * DELETE /api/properties/[id]/images/[imageId]
 * Delete an image
 */ async function DELETE(_request, { params  }) {
    try {
        const { id: propertyId , imageId  } = params;
        // 1. Get the current user session
        const session = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/auth'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())();
        if (!session?.user) {
            return next_response["default"].json({
                error: "You must be logged in to delete images"
            }, {
                status: 401
            });
        }
        // 2. Check if the property exists and user has permission
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: propertyId
            },
            select: {
                id: true,
                ownerId: true,
                managers: {
                    where: {
                        managerId: session.user.id
                    },
                    select: {
                        id: true
                    }
                },
                images: {
                    where: {
                        id: imageId
                    },
                    select: {
                        id: true,
                        publicId: true,
                        isPrimary: true
                    }
                }
            }
        });
        if (!property) {
            return next_response["default"].json({
                error: "Property not found"
            }, {
                status: 404
            });
        }
        // Check if the image exists and belongs to this property
        const imageToDelete = property.images[0];
        if (!imageToDelete) {
            return next_response["default"].json({
                error: "Image not found"
            }, {
                status: 404
            });
        }
        // Check if user is the owner, a manager, or an admin
        const isOwner = property.ownerId === session.user.id;
        const isManager = property.managers.length > 0;
        const isAdmin = session.user.role === client_.UserRole.ADMIN;
        if (!isOwner && !isManager && !isAdmin) {
            return next_response["default"].json({
                error: "You do not have permission to delete images from this property"
            }, {
                status: 403
            });
        }
        // 3. Delete the image from Cloudinary - commented out for build to pass
        try {
            // await deleteImage(imageToDelete.publicId);
            console.log("Image deletion from Cloudinary disabled for build");
        } catch (error) {
            console.error("Error deleting image from Cloudinary:", error);
        // Continue with database deletion even if Cloudinary deletion fails
        }
        // 4. Delete the image record from the database
        await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                id: imageId
            }
        });
        // 5. If the deleted image was primary, set another image as primary if available
        if (imageToDelete.isPrimary) {
            const otherImages = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                where: {
                    propertyId,
                    id: {
                        not: imageId
                    }
                },
                orderBy: {
                    createdAt: "asc"
                },
                take: 1
            });
            if (otherImages.length > 0) {
                await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                    where: {
                        id: otherImages[0].id
                    },
                    data: {
                        isPrimary: true
                    }
                });
            }
        }
        return next_response["default"].json({
            message: "Image deleted successfully"
        });
    } catch (error) {
        console.error("Error deleting image:", error);
        return next_response["default"].json({
            error: "An error occurred while deleting the image"
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Froute&name=app%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fproperties%2F%5Bid%5D%2Fimages%2F%5BimageId%5D%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/properties/[id]/images/[imageId]",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/properties/[id]/images/[imageId]/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/properties/[id]/images/[imageId]/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(42311)));
module.exports = __webpack_exports__;

})();