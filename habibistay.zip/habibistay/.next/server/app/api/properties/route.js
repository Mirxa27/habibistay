"use strict";
(() => {
var exports = {};
exports.id = 8805;
exports.ids = [8805];
exports.modules = {

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 82485:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/properties/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "OPTIONS": () => (OPTIONS),
  "POST": () => (POSTWithCors)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
;// CONCATENATED MODULE: ./src/app/api/properties/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());


async function handlePost(request) {
    try {
        // Get user ID and role from the request headers (set by the middleware)
        const userId = request.headers.get("x-user-id");
        const userRole = request.headers.get("x-user-role");
        // Check if user is authenticated
        if (!userId) {
            return next_response["default"].json({
                error: "Unauthorized: Authentication required"
            }, {
                status: 401
            });
        }
        // Check if user has the required role (HOST, PROPERTY_MANAGER, or ADMIN)
        // Need to check as string for the build to pass
        if (![
            "HOST",
            "PROPERTY_MANAGER",
            "ADMIN"
        ].includes(userRole)) {
            return next_response["default"].json({
                error: "Forbidden: Insufficient permissions to create a property"
            }, {
                status: 403
            });
        }
        // Parse the request body
        const body = await request.json();
        // Validate required fields
        const requiredFields = [
            "title",
            "description",
            "type",
            "price",
            "address",
            "city",
            "country",
            "bedrooms",
            "beds",
            "bathrooms",
            "maxGuests",
            "amenities"
        ];
        const missingFields = requiredFields.filter((field)=>!(field in body));
        if (missingFields.length > 0) {
            return next_response["default"].json({
                error: `Missing required fields: ${missingFields.join(", ")}`
            }, {
                status: 400
            });
        }
        // Additional validation for numeric fields
        if (body.price <= 0) {
            return next_response["default"].json({
                error: "Price must be greater than 0"
            }, {
                status: 400
            });
        }
        // Create the property in the database
        const property = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            data: {
                title: body.title,
                description: body.description,
                type: body.type,
                price: body.price,
                cleaningFee: body.cleaningFee,
                serviceFee: body.serviceFee,
                address: body.address,
                city: body.city,
                state: body.state,
                zipCode: body.zipCode,
                country: body.country,
                lat: body.lat,
                lng: body.lng,
                bedrooms: body.bedrooms,
                beds: body.beds,
                bathrooms: body.bathrooms,
                maxGuests: body.maxGuests,
                amenities: body.amenities,
                houseRules: body.houseRules,
                cancellationPolicy: body.cancellationPolicy,
                isPublished: body.isPublished || false,
                ownerId: userId
            },
            // Select only the fields we want to return
            select: {
                id: true,
                title: true,
                description: true,
                type: true,
                price: true,
                cleaningFee: true,
                serviceFee: true,
                address: true,
                city: true,
                state: true,
                zipCode: true,
                country: true,
                lat: true,
                lng: true,
                bedrooms: true,
                beds: true,
                bathrooms: true,
                maxGuests: true,
                amenities: true,
                houseRules: true,
                cancellationPolicy: true,
                isPublished: true,
                ownerId: true,
                createdAt: true,
                updatedAt: true
            }
        });
        return next_response["default"].json(property, {
            status: 201
        });
    } catch (error) {
        console.error("Error creating property:", error);
        // Handle specific Prisma errors
        if (error instanceof Error) {
            if (error.name === "PrismaClientKnownRequestError") {
                return next_response["default"].json({
                    error: "Database error occurred while creating property"
                }, {
                    status: 500
                });
            }
        }
        // Generic error response
        return next_response["default"].json({
            error: "An unexpected error occurred while creating the property"
        }, {
            status: 500
        });
    }
}
// Add OPTIONS handler for CORS preflight requests
async function OPTIONS() {
    return new next_response["default"](null, {
        status: 204,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization"
        }
    });
}
// Add CORS headers to all responses
const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization"
};
// Export a custom response handler to add CORS headers
const withCors = (response)=>{
    Object.entries(corsHeaders).forEach(([key, value])=>{
        response.headers.set(key, value);
    });
    return response;
};
// Export the POST handler with CORS
const POSTWithCors = async (request)=>{
    const response = await handlePost(request); // Changed to handlePost
    return withCors(response);
};


;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fproperties%2Froute&name=app%2Fapi%2Fproperties%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproperties%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fproperties%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/properties",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/properties/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/properties/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(82485)));
module.exports = __webpack_exports__;

})();