"use strict";
(() => {
var exports = {};
exports.id = 168;
exports.ids = [168];
exports.modules = {

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 42590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/auth/request-password-reset/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "POST": () => (POST)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "crypto"
var external_crypto_ = __webpack_require__(6113);
var external_crypto_default = /*#__PURE__*/__webpack_require__.n(external_crypto_);
;// CONCATENATED MODULE: ./src/app/api/auth/request-password-reset/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());

 // Assumes @/ maps to habibistay/src

async function POST(request) {
    try {
        const body = await request.json();
        const { email  } = body;
        if (!email) {
            return next_response["default"].json({
                error: "Email is required"
            }, {
                status: 400
            });
        }
        const user = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                email
            }
        });
        if (user) {
            // User found, proceed to generate and store token
            const token = external_crypto_default().randomBytes(32).toString("hex");
            const expiresAt = new Date(Date.now() + 3600000); // Token expires in 1 hour
            // Invalidate any existing tokens for this user (optional, but good practice)
            await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                where: {
                    userId: user.id
                }
            });
            await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
                data: {
                    userId: user.id,
                    token: token,
                    expiresAt: expiresAt
                }
            });
            // --- BEGIN EMAIL SENDING LOGIC (Subtask 6.4 Placeholder) ---
            // In a full implementation, you would integrate an email service like Resend here.
            // 1. Import the email sending library (e.g., `import { Resend } from 'resend';`)
            // 2. Initialize the client (e.g., `const resend = new Resend(process.env.RESEND_API_KEY);`)
            // 3. Construct the reset URL (e.g., `${process.env.NEXTAUTH_URL}/reset-password?token=${token}`)
            // 4. Define email content (HTML or text). Example:
            //    Subject: "Password Reset Request for HabibiStay"
            //    Body: `Hello, you requested a password reset. 
            //           Click this link to reset your password: ${resetUrl}
            //           This link is valid for 1 hour. 
            //           If you did not request this, please ignore this email.`
            // 5. Send the email:
            //    try {
            //      await resend.emails.send({
            //        from: process.env.EMAIL_FROM || 'HabibiStay <no-reply@yourdomain.com>',
            //        to: user.email,
            //        subject: 'Password Reset Request for HabibiStay',
            //        html: `<p>Click <a href="${resetUrl}">here</a> to reset your password. Link is valid for 1 hour.</p>`, // Or use React Email
            //      });
            //      console.log(`Password reset email successfully initiated for ${email}`);
            //    } catch (emailError) {
            //      console.error(`Failed to send password reset email to ${email}:`, emailError);
            //      // Potentially handle this error, e.g., by not invalidating the token immediately or logging for retry
            //    }
            // For now, logging to console:
            const resetUrl = `${process.env.NEXTAUTH_URL || "http://localhost:3000"}/reset-password?token=${token}`;
            console.log(`SIMULATING EMAIL SEND: Password reset token for ${email}: ${token}`);
            console.log(`SIMULATING EMAIL SEND: Reset link: ${resetUrl}`);
        // --- END EMAIL SENDING LOGIC (Subtask 6.4 Placeholder) ---
        } else {
            // User not found, but we don't want to reveal this.
            // Log this attempt for security monitoring if desired.
            console.log(`Password reset requested for non-existent email: ${email}`);
        }
        // Always return a generic success message to prevent email enumeration
        return next_response["default"].json({
            message: "If your email address is in our system, you will receive a password reset link shortly."
        }, {
            status: 200
        });
    } catch (error) {
        console.error("Request password reset error:", error);
        return next_response["default"].json({
            error: "An unexpected error occurred."
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fauth%2Frequest-password-reset%2Froute&name=app%2Fapi%2Fauth%2Frequest-password-reset%2Froute&pagePath=private-next-app-dir%2Fapi%2Fauth%2Frequest-password-reset%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fauth%2Frequest-password-reset%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/auth/request-password-reset",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/auth/request-password-reset/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/auth/request-password-reset/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(42590)));
module.exports = __webpack_exports__;

})();