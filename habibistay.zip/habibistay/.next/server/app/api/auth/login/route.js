"use strict";
(() => {
var exports = {};
exports.id = 8873;
exports.ids = [8873];
exports.modules = {

/***/ 67096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 11299:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "headerHooks": () => (/* binding */ headerHooks),
  "originalPathname": () => (/* binding */ originalPathname),
  "requestAsyncStorage": () => (/* binding */ requestAsyncStorage),
  "routeModule": () => (/* binding */ routeModule),
  "serverHooks": () => (/* binding */ serverHooks),
  "staticGenerationAsyncStorage": () => (/* binding */ staticGenerationAsyncStorage),
  "staticGenerationBailout": () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./src/app/api/auth/login/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  "POST": () => (POST)
});

// EXTERNAL MODULE: ../node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(46086);
// EXTERNAL MODULE: ../node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(96158);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ../node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(49639);
// EXTERNAL MODULE: external "bcrypt"
var external_bcrypt_ = __webpack_require__(67096);
var external_bcrypt_default = /*#__PURE__*/__webpack_require__.n(external_bcrypt_);
;// CONCATENATED MODULE: ./src/app/api/auth/login/route.ts
Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());
Object(function webpackMissingModule() { var e = new Error("Cannot find module 'jsonwebtoken'"); e.code = 'MODULE_NOT_FOUND'; throw e; }());

 // Assumes @/ maps to habibistay/src


async function POST(request) {
    try {
        const body = await request.json();
        const { email , password  } = body;
        // 1. Validate input
        if (!email || !password) {
            return next_response["default"].json({
                error: "Email and password are required"
            }, {
                status: 400
            });
        }
        // 2. Find user by email
        const user = await Object(function webpackMissingModule() { var e = new Error("Cannot find module '@habibistay/lib/prisma'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            where: {
                email
            }
        });
        if (!user) {
            return next_response["default"].json({
                error: "Invalid credentials"
            }, {
                status: 401
            }); // User not found
        }
        if (!user.password) {
            // This case might happen if user signed up via OAuth and doesn't have a password
            return next_response["default"].json({
                error: "Login with password not available for this account. Try a different login method."
            }, {
                status: 403
            });
        }
        // 3. Compare password
        const isPasswordValid = await external_bcrypt_default().compare(password, user.password);
        if (!isPasswordValid) {
            return next_response["default"].json({
                error: "Invalid credentials"
            }, {
                status: 401
            }); // Incorrect password
        }
        // 4. If valid, return user data (sans password)
        // Token generation will be handled in subtask 3.4
        // For now, just confirm authentication is successful
        const { password: _ , ...userWithoutPassword } = user;
        // 5. Generate JWT
        const jwtSecret = process.env.JWT_SECRET;
        if (!jwtSecret) {
            console.error("JWT_SECRET is not defined in environment variables.");
            return next_response["default"].json({
                error: "Server configuration error."
            }, {
                status: 500
            });
        }
        const token = Object(function webpackMissingModule() { var e = new Error("Cannot find module 'jsonwebtoken'"); e.code = 'MODULE_NOT_FOUND'; throw e; }())({
            userId: userWithoutPassword.id,
            email: userWithoutPassword.email,
            role: userWithoutPassword.role
        }, jwtSecret, {
            expiresIn: "1h"
        } // Token expires in 1 hour
        );
        return next_response["default"].json({
            message: "Login successful",
            user: userWithoutPassword,
            token: token
        }, {
            status: 200
        });
    } catch (error) {
        console.error("Login error:", error);
        return next_response["default"].json({
            error: "An unexpected error occurred during login."
        }, {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fauth%2Flogin%2Froute&name=app%2Fapi%2Fauth%2Flogin%2Froute&pagePath=private-next-app-dir%2Fapi%2Fauth%2Flogin%2Froute.ts&appDir=%2FUsers%2Fabdullahmirxa%2FDownloads%2FOnline-Booking-Management-main%2Fhabibistay%2Fsrc%2Fapp&appPaths=%2Fapi%2Fauth%2Flogin%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const routeModule = new (module_default())({
    userland: route_namespaceObject,
    pathname: "/api/auth/login",
    resolvedPagePath: "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/api/auth/login/route.ts",
    nextConfigOutput: undefined,
  })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/auth/login/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,6272,2706], () => (__webpack_exec__(11299)));
module.exports = __webpack_exports__;

})();