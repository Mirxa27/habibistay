(() => {
var exports = {};
exports.id = 3016;
exports.ids = [3016];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 92761:
/***/ ((module) => {

"use strict";
module.exports = require("node:async_hooks");

/***/ }),

/***/ 17718:
/***/ ((module) => {

"use strict";
module.exports = require("node:child_process");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 15673:
/***/ ((module) => {

"use strict";
module.exports = require("node:events");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 93977:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 70612:
/***/ ((module) => {

"use strict";
module.exports = require("node:os");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 25997:
/***/ ((module) => {

"use strict";
module.exports = require("node:tty");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 94250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79346);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68365);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82934);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48520);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(88991);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87042);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(90140);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(75266);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79421);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(61920);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(49408);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57258);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(81745);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'host',
        {
        children: [
        'analytics',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16024)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/host/analytics/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64337)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/host/analytics/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/host/analytics/page"
  

/***/ }),

/***/ 18917:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94389))

/***/ }),

/***/ 94389:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HostAnalyticsPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ../node_modules/next/navigation.js
var navigation = __webpack_require__(52865);
// EXTERNAL MODULE: ../node_modules/next-auth/react.js + 2 modules
var react = __webpack_require__(27258);
// EXTERNAL MODULE: ./src/components/layout/MainLayout.tsx + 1 modules
var MainLayout = __webpack_require__(93514);
;// CONCATENATED MODULE: ./src/components/host/AnalyticsSummaryCards.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 
// Placeholder icon components since we're having issues with react-icons
const IconComponent = ({ className , children  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: `inline-block ${className || ""}`,
        style: {
            width: "1em",
            height: "1em"
        },
        children: children
    });
const FaCalendarCheck = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDCC5"
    });
const FaChartLine = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDCC8"
    });
const FaDollarSign = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDCB2"
    });
const FaBan = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDEAB"
    });
const FaPercentage = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "%"
    });
const FaMoneyBillWave = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDCB5"
    });
function AnalyticsSummaryCards({ summary  }) {
    const formatCurrency = (value)=>{
        return new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: "USD",
            minimumFractionDigits: 2
        }).format(value);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white rounded-lg shadow-sm p-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-start justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm uppercase text-gray-500 font-medium",
                                        children: "Total Bookings"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mt-2 text-3xl font-semibold",
                                        children: summary.totalBookings
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bg-blue-100 p-3 rounded-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaCalendarCheck, {
                                    className: "h-6 w-6 text-blue-600"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "text-sm text-gray-500 mt-4",
                        children: [
                            summary.confirmedBookings,
                            " confirmed (",
                            Math.round(summary.confirmedBookings / Math.max(1, summary.totalBookings) * 100),
                            "%)"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white rounded-lg shadow-sm p-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-start justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm uppercase text-gray-500 font-medium",
                                        children: "Total Revenue"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mt-2 text-3xl font-semibold",
                                        children: formatCurrency(summary.totalRevenue)
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bg-green-100 p-3 rounded-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaDollarSign, {
                                    className: "h-6 w-6 text-green-600"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "text-sm text-gray-500 mt-4",
                        children: [
                            "Avg. $",
                            Math.round(summary.averageBookingValue),
                            " per booking"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white rounded-lg shadow-sm p-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-start justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm uppercase text-gray-500 font-medium",
                                        children: "Avg. Booking Value"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mt-2 text-3xl font-semibold",
                                        children: formatCurrency(summary.averageBookingValue)
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bg-purple-100 p-3 rounded-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaMoneyBillWave, {
                                    className: "h-6 w-6 text-purple-600"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-gray-500 mt-4",
                        children: "Per confirmed booking"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white rounded-lg shadow-sm p-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-start justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm uppercase text-gray-500 font-medium",
                                        children: "Occupancy Rate"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: "mt-2 text-3xl font-semibold",
                                        children: [
                                            Math.round(summary.occupancyRate),
                                            "%"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bg-indigo-100 p-3 rounded-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaPercentage, {
                                    className: "h-6 w-6 text-indigo-600"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-gray-500 mt-4",
                        children: "Average across all properties"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white rounded-lg shadow-sm p-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-start justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm uppercase text-gray-500 font-medium",
                                        children: "Confirmed Bookings"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mt-2 text-3xl font-semibold",
                                        children: summary.confirmedBookings
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bg-teal-100 p-3 rounded-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaChartLine, {
                                    className: "h-6 w-6 text-teal-600"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-gray-500 mt-4",
                        children: "CONFIRMED or COMPLETED status"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white rounded-lg shadow-sm p-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-start justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm uppercase text-gray-500 font-medium",
                                        children: "Cancelled Bookings"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mt-2 text-3xl font-semibold",
                                        children: summary.cancelledBookings
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bg-red-100 p-3 rounded-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaBan, {
                                    className: "h-6 w-6 text-red-600"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-gray-500 mt-4",
                        children: summary.totalBookings > 0 ? `${Math.round(summary.cancelledBookings / summary.totalBookings * 100)}% cancellation rate` : "No bookings yet"
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/hooks/useHostAnalytics.ts
/* __next_internal_client_entry_do_not_use__ default auto */ 

function useHostAnalytics() {
    const { data: session  } = (0,react/* useSession */.kP)();
    const [analyticsData, setAnalyticsData] = (0,react_.useState)(null);
    const [loading, setLoading] = (0,react_.useState)(false);
    const [error, setError] = (0,react_.useState)(null);
    const fetchAnalytics = async (timeframe = "last6Months", propertyId)=>{
        if (!session?.user) {
            setError("You must be logged in to access analytics");
            return;
        }
        setLoading(true);
        setError(null);
        try {
            // Build query string
            const params = new URLSearchParams();
            params.append("timeframe", timeframe);
            if (propertyId) {
                params.append("propertyId", propertyId);
            }
            const response = await fetch(`/api/host/analytics?${params.toString()}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Error: ${response.status}`);
            }
            const data = await response.json();
            setAnalyticsData(data);
            return data;
        } catch (error) {
            setError(error instanceof Error ? error.message : "Failed to load analytics data");
            console.error("Error fetching analytics:", error);
            return null;
        } finally{
            setLoading(false);
        }
    };
    return {
        analyticsData,
        loading,
        error,
        fetchAnalytics
    };
}

// EXTERNAL MODULE: ../node_modules/date-fns/index.js
var date_fns = __webpack_require__(58525);
;// CONCATENATED MODULE: ./src/app/host/analytics/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



// Placeholder for react-icons
const IconPlaceholder = ({ name , className  })=>{
    const icons = {
        FaSpinner: "⟳",
        FaChartPie: "\uD83D\uDCCA",
        FaCalendarAlt: "\uD83D\uDCC5"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: className,
        children: icons[name] || "•"
    });
};

// Using local stub components for build

// Placeholder components for build
const BookingStatusChart = ({ bookingStatusData  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-white p-6 rounded-lg shadow-md",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-lg font-medium mb-4",
                children: "Booking Status Breakdown"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "p-4 bg-gray-50 rounded",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "text-center text-sm text-gray-500",
                    children: bookingStatusData ? `Chart showing ${Object.keys(bookingStatusData).length} statuses` : "(Booking status chart)"
                })
            })
        ]
    });
const RevenueChart = ({ monthlyData  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-white p-6 rounded-lg shadow-md",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-lg font-medium mb-4",
                children: "Monthly Revenue"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "p-4 bg-gray-50 rounded",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "text-center text-sm text-gray-500",
                    children: monthlyData ? `Chart showing ${monthlyData.length} months of data` : "(Revenue chart)"
                })
            })
        ]
    });
const PropertyPerformanceTable = ({ properties  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-white p-6 rounded-lg shadow-md",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-lg font-medium mb-4",
                children: "Property Performance"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                    className: "min-w-full divide-y divide-gray-200",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                            className: "bg-gray-50",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                        scope: "col",
                                        className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                                        children: "Property"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                        scope: "col",
                                        className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                                        children: "Bookings"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                        scope: "col",
                                        className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                                        children: "Revenue"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                        scope: "col",
                                        className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                                        children: "Occupancy"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                            className: "bg-white divide-y divide-gray-200",
                            children: properties && properties.length > 0 ? properties.map((property, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            className: "px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900",
                                            children: property.title || `Property ${index + 1}`
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500",
                                            children: property.bookings || 0
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                            className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500",
                                            children: [
                                                "$",
                                                property.revenue || 0
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                            className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500",
                                            children: [
                                                property.occupancyRate || 0,
                                                "%"
                                            ]
                                        })
                                    ]
                                }, property.id || index)) : /*#__PURE__*/ jsx_runtime_.jsx("tr", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    colSpan: 4,
                                    className: "px-6 py-4 text-center text-sm text-gray-500",
                                    children: "(No property performance data available)"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });


function HostAnalyticsPage() {
    const router = (0,navigation.useRouter)();
    const searchParams = (0,navigation.useSearchParams)();
    const { data: session , status  } = (0,react/* useSession */.kP)();
    const { analyticsData , loading , error , fetchAnalytics  } = useHostAnalytics();
    const [timeframe, setTimeframe] = (0,react_.useState)("last6Months");
    const [propertyId, setPropertyId] = (0,react_.useState)(searchParams.get("propertyId") || undefined);
    // Redirect if not authenticated or not a host
    (0,react_.useEffect)(()=>{
        if (status === "unauthenticated") {
            router.push("/login");
        } else if (status === "authenticated" && session?.user?.role !== "HOST" && session?.user?.role !== "PROPERTY_MANAGER" && session?.user?.role !== "ADMIN") {
            router.push("/");
        }
    }, [
        router,
        status,
        session
    ]);
    // Fetch analytics data when the component mounts or parameters change
    (0,react_.useEffect)(()=>{
        if (status === "authenticated" && (session?.user?.role === "HOST" || session?.user?.role === "PROPERTY_MANAGER" || session?.user?.role === "ADMIN")) {
            fetchAnalytics(timeframe, propertyId);
        }
    }, [
        status,
        timeframe,
        propertyId,
        session
    ]);
    // Handle timeframe change
    const handleTimeframeChange = (newTimeframe)=>{
        setTimeframe(newTimeframe);
    };
    // Format date range for display
    const formatDateRange = ()=>{
        if (!analyticsData) return "";
        const startDate = new Date(analyticsData.dateRange.startDate);
        const endDate = new Date(analyticsData.dateRange.endDate);
        return `${(0,date_fns.format)(startDate, "MMMM d, yyyy")} - ${(0,date_fns.format)(endDate, "MMMM d, yyyy")}`;
    };
    // Loading state
    if (status === "loading" || loading) {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto px-4 py-16",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl font-semibold mb-8",
                        children: "Host Analytics"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex items-center justify-center py-12",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                            name: "FaSpinner",
                            className: "animate-spin text-blue-600 text-4xl"
                        })
                    })
                ]
            })
        });
    }
    // Unauthorized access
    if (status === "authenticated" && session?.user?.role !== "HOST" && session?.user?.role !== "PROPERTY_MANAGER" && session?.user?.role !== "ADMIN") {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto px-4 py-16",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl font-semibold mb-4",
                        children: "Host Analytics"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "bg-yellow-50 border-l-4 border-yellow-400 p-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "ml-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-yellow-700",
                                    children: "You need to be a host to access this page."
                                })
                            })
                        })
                    })
                ]
            })
        });
    }
    // Error state
    if (error) {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto px-4 py-16",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl font-semibold mb-4",
                        children: "Host Analytics"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "bg-red-50 border-l-4 border-red-400 p-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "ml-3",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: "text-red-700",
                                        children: [
                                            "Error loading analytics data: ",
                                            error
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: ()=>fetchAnalytics(timeframe, propertyId),
                                        className: "mt-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700",
                                        children: "Try Again"
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container mx-auto px-4 py-16",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col md:flex-row md:items-center md:justify-between mb-8",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "text-3xl font-semibold",
                                    children: "Host Analytics"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "mt-2 text-neutral-500 flex items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                            name: "FaCalendarAlt",
                                            className: "mr-2"
                                        }),
                                        formatDateRange()
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-4 md:mt-0 flex items-center space-x-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-sm text-gray-500",
                                    children: "Timeframe:"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "inline-flex rounded-md shadow-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: `px-4 py-2 text-sm font-medium rounded-l-md ${timeframe === "thisMonth" ? "bg-blue-600 text-white" : "bg-white text-gray-700 hover:bg-gray-50"} border border-gray-300`,
                                            onClick: ()=>handleTimeframeChange("thisMonth"),
                                            children: "This Month"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: `px-4 py-2 text-sm font-medium ${timeframe === "last3Months" ? "bg-blue-600 text-white" : "bg-white text-gray-700 hover:bg-gray-50"} border-t border-b border-gray-300`,
                                            onClick: ()=>handleTimeframeChange("last3Months"),
                                            children: "3 Months"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: `px-4 py-2 text-sm font-medium ${timeframe === "last6Months" ? "bg-blue-600 text-white" : "bg-white text-gray-700 hover:bg-gray-50"} border-t border-b border-gray-300`,
                                            onClick: ()=>handleTimeframeChange("last6Months"),
                                            children: "6 Months"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: `px-4 py-2 text-sm font-medium rounded-r-md ${timeframe === "lastYear" ? "bg-blue-600 text-white" : "bg-white text-gray-700 hover:bg-gray-50"} border border-gray-300`,
                                            onClick: ()=>handleTimeframeChange("lastYear"),
                                            children: "1 Year"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                propertyId && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mb-6 bg-blue-50 border-l-4 border-blue-400 p-4",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-blue-700",
                                children: [
                                    "Viewing analytics for a specific property.",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-medium ml-1",
                                        children: analyticsData?.propertyPerformance.find((p)=>p.id === propertyId)?.title || "Property"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>{
                                    setPropertyId(undefined);
                                    router.push("/host/analytics");
                                },
                                className: "text-blue-700 hover:text-blue-900 font-medium",
                                children: "View All Properties"
                            })
                        ]
                    })
                }),
                analyticsData ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(AnalyticsSummaryCards, {
                            summary: analyticsData.summary
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(RevenueChart, {
                                    monthlyData: analyticsData.monthlyData
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(BookingStatusChart, {
                                    bookingStatusData: analyticsData.bookingStatusBreakdown
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mt-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(PropertyPerformanceTable, {
                                properties: analyticsData.propertyPerformance
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-8 bg-gray-50 border border-gray-200 rounded-lg p-6 text-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-lg font-medium mb-2",
                                    children: "Want to boost your performance?"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-gray-600 mb-4",
                                    children: "Improve your property listings, adjust pricing, or get tips on how to attract more guests."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    className: "px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 inline-flex items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                            name: "FaChartPie",
                                            className: "mr-2"
                                        }),
                                        "Get Optimization Tips"
                                    ]
                                })
                            ]
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "text-center py-12",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-gray-500",
                        children: "No analytics data available. Try changing the timeframe."
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 16024:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63296);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/host/analytics/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 33533:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(49472)


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,4179,9633,9472,9658,5406,9091,153,3670], () => (__webpack_exec__(94250)));
module.exports = __webpack_exports__;

})();