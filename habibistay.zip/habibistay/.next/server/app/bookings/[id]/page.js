(() => {
var exports = {};
exports.id = 5197;
exports.ids = [5197];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 92761:
/***/ ((module) => {

"use strict";
module.exports = require("node:async_hooks");

/***/ }),

/***/ 17718:
/***/ ((module) => {

"use strict";
module.exports = require("node:child_process");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 15673:
/***/ ((module) => {

"use strict";
module.exports = require("node:events");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 93977:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 70612:
/***/ ((module) => {

"use strict";
module.exports = require("node:os");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 25997:
/***/ ((module) => {

"use strict";
module.exports = require("node:tty");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 69310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79346);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68365);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82934);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48520);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(88991);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87042);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(90140);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(75266);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79421);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(61920);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(49408);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57258);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(81745);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'bookings',
        {
        children: [
        '[id]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89092)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/bookings/[id]/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64337)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/bookings/[id]/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/bookings/[id]/page"
  

/***/ }),

/***/ 83917:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 53660))

/***/ }),

/***/ 53660:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BookingDetailsPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ../node_modules/next/navigation.js
var navigation = __webpack_require__(52865);
// EXTERNAL MODULE: ../node_modules/next-auth/react.js + 2 modules
var react = __webpack_require__(27258);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(64427);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ../node_modules/next/link.js
var next_link = __webpack_require__(33533);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ../node_modules/date-fns/index.js
var date_fns = __webpack_require__(58525);
// EXTERNAL MODULE: ../node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(35562);
// EXTERNAL MODULE: ./src/components/layout/MainLayout.tsx + 1 modules
var MainLayout = __webpack_require__(93514);
// EXTERNAL MODULE: ./src/hooks/useBookings.ts
var useBookings = __webpack_require__(73999);
// EXTERNAL MODULE: ../node_modules/@prisma/client/default.js
var client_default = __webpack_require__(7641);
;// CONCATENATED MODULE: ./src/components/bookings/BookingStatusTimeline.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



// Temporarily comment out for build to pass
// import { 
//   FaRegClock, 
//   FaRegCheckCircle, 
//   FaRegTimesCircle,
//   FaRegCalendarCheck,
//   FaRegStar
// } from 'react-icons/fa';
// Placeholder icons for build
const IconMap = {
    FaRegClock: "\uD83D\uDD52",
    FaRegCheckCircle: "✓",
    FaRegTimesCircle: "✗",
    FaRegCalendarCheck: "\uD83D\uDCC5",
    FaRegStar: "⭐"
};
const BookingStatusTimeline = ({ booking  })=>{
    const [events, setEvents] = (0,react_.useState)([]);
    (0,react_.useEffect)(()=>{
        if (!booking) return;
        // Create timeline events based on booking
        const timelineEvents = [];
        const now = new Date();
        // Created event (always present)
        timelineEvents.push({
            status: "created",
            date: new Date(booking.createdAt),
            iconName: "FaRegClock",
            color: "bg-blue-500",
            label: "Booking Requested",
            description: `Booking created on ${(0,date_fns.format)(new Date(booking.createdAt), "MMMM d, yyyy")}`,
            completed: true,
            current: false
        });
        // Add status events based on booking status
        if (booking.status === client_default.BookingStatus.CONFIRMED || booking.status === client_default.BookingStatus.COMPLETED) {
            // Find when the booking was confirmed
            const confirmedDate = booking.updatedAt ? new Date(booking.updatedAt) : new Date(booking.createdAt);
            timelineEvents.push({
                status: "confirmed",
                date: confirmedDate,
                iconName: "FaRegCheckCircle",
                color: "bg-green-500",
                label: "Booking Confirmed",
                description: `Your booking was confirmed on ${(0,date_fns.format)(confirmedDate, "MMMM d, yyyy")}`,
                completed: true,
                current: booking.status === client_default.BookingStatus.CONFIRMED
            });
        }
        if (booking.status === client_default.BookingStatus.CANCELLED) {
            // Add cancellation event
            const cancelledDate = booking.updatedAt ? new Date(booking.updatedAt) : new Date();
            timelineEvents.push({
                status: "cancelled",
                date: cancelledDate,
                iconName: "FaRegTimesCircle",
                color: "bg-red-500",
                label: "Booking Cancelled",
                description: `Booking was cancelled on ${(0,date_fns.format)(cancelledDate, "MMMM d, yyyy")}`,
                completed: true,
                current: true
            });
        } else if (booking.status === client_default.BookingStatus.REJECTED) {
            // Add rejection event
            const rejectedDate = booking.updatedAt ? new Date(booking.updatedAt) : new Date();
            timelineEvents.push({
                status: "rejected",
                date: rejectedDate,
                iconName: "FaRegTimesCircle",
                color: "bg-red-500",
                label: "Booking Rejected",
                description: `Booking was rejected by the host on ${(0,date_fns.format)(rejectedDate, "MMMM d, yyyy")}`,
                completed: true,
                current: true
            });
        } else {
            // Add check-in event for non-cancelled bookings
            const checkInDate = new Date(booking.checkInDate);
            const isCheckInCompleted = now > checkInDate;
            timelineEvents.push({
                status: "check-in",
                date: checkInDate,
                iconName: "FaRegCalendarCheck",
                color: "bg-purple-500",
                label: "Check-in",
                description: `Check-in on ${(0,date_fns.format)(checkInDate, "MMMM d, yyyy")}`,
                completed: isCheckInCompleted,
                current: now >= checkInDate && now < new Date(booking.checkOutDate) && booking.status !== client_default.BookingStatus.COMPLETED
            });
            // Add check-out event
            const checkOutDate = new Date(booking.checkOutDate);
            const isCheckOutCompleted = now > checkOutDate;
            timelineEvents.push({
                status: "check-out",
                date: checkOutDate,
                iconName: "FaRegCalendarCheck",
                color: "bg-yellow-500",
                label: "Check-out",
                description: `Check-out on ${(0,date_fns.format)(checkOutDate, "MMMM d, yyyy")}`,
                completed: isCheckOutCompleted,
                current: isCheckOutCompleted && booking.status !== client_default.BookingStatus.COMPLETED
            });
            // Add completed event if booking is completed
            if (booking.status === client_default.BookingStatus.COMPLETED) {
                const completedDate = booking.updatedAt ? new Date(booking.updatedAt) : new Date(checkOutDate);
                timelineEvents.push({
                    status: "completed",
                    date: completedDate,
                    iconName: "FaRegStar",
                    color: "bg-blue-500",
                    label: "Stay Completed",
                    description: `Your stay was completed on ${(0,date_fns.format)(completedDate, "MMMM d, yyyy")}`,
                    completed: true,
                    current: true
                });
            }
        }
        // Sort events by date
        timelineEvents.sort((a, b)=>a.date.getTime() - b.date.getTime());
        setEvents(timelineEvents);
    }, [
        booking
    ]);
    if (!booking || events.length === 0) return null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-white rounded-lg shadow px-6 py-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-lg font-semibold mb-4",
                children: "Booking Timeline"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative",
                children: events.map((event, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex mb-6 last:mb-0",
                        children: [
                            index < events.length - 1 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "absolute left-3.5 top-8 bottom-0 w-0.5 bg-gray-200 h-full"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `relative flex-shrink-0 z-10 w-8 h-8 rounded-full ${event.color} flex items-center justify-center text-white`,
                                children: IconMap[event.iconName] || "•"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "ml-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: `font-medium ${event.current ? "text-gray-900" : "text-gray-700"}`,
                                                children: event.label
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "ml-2 text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-600",
                                                children: (0,date_fns.format)(event.date, "MMM d, yyyy")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: `text-sm mt-1 ${event.current ? "text-gray-600" : "text-gray-500"}`,
                                        children: event.description
                                    }),
                                    event.status === "check-in" && event.completed && !event.current && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm text-green-600 mt-1",
                                        children: "Checked in"
                                    }),
                                    event.status === "check-out" && event.completed && !event.current && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm text-green-600 mt-1",
                                        children: "Checked out"
                                    })
                                ]
                            })
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const bookings_BookingStatusTimeline = (BookingStatusTimeline);

;// CONCATENATED MODULE: ./src/app/bookings/[id]/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







// Temporarily use text placeholders instead of react-icons for build
// import { FaCalendarAlt, FaUsers, FaMoneyBillWave, FaMapMarkerAlt, FaCheckCircle, FaTimesCircle, FaInfoCircle } from 'react-icons/fa';




// Placeholder components for the build
const IconPlaceholder = ({ name  })=>{
    const icons = {
        FaCalendarAlt: "\uD83D\uDCC5",
        FaUsers: "\uD83D\uDC65",
        FaMoneyBillWave: "\uD83D\uDCB0",
        FaMapMarkerAlt: "\uD83D\uDCCD",
        FaCheckCircle: "✓",
        FaTimesCircle: "✗",
        FaInfoCircle: "ℹ️"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: "mr-2",
        children: icons[name] || "•"
    });
};
function BookingDetailsPage({ params  }) {
    const router = (0,navigation.useRouter)();
    const { status: authStatus  } = (0,react/* useSession */.kP)(); // Simplified for build
    const { getBooking , cancelBooking , currentBooking , isLoading  } = (0,useBookings/* useBookings */.o)();
    const [isProcessing, setIsProcessing] = (0,react_.useState)(false);
    const bookingId = params.id;
    // Redirect if not authenticated
    (0,react_.useEffect)(()=>{
        if (authStatus === "unauthenticated") {
            router.push("/login");
        }
    }, [
        router,
        authStatus
    ]);
    // Fetch booking when session is loaded
    (0,react_.useEffect)(()=>{
        if (authStatus === "authenticated" && bookingId) {
            fetchBooking();
        }
    }, [
        authStatus,
        bookingId
    ]);
    // Fetch booking details
    const fetchBooking = async ()=>{
        try {
            await getBooking(bookingId);
        } catch (error) {
            console.error("Error fetching booking:", error);
            dist/* toast.error */.Am.error("Failed to load booking details");
        }
    };
    // Handle cancel booking
    const handleCancelBooking = async ()=>{
        if (confirm("Are you sure you want to cancel this booking? This action cannot be undone.")) {
            setIsProcessing(true);
            try {
                await cancelBooking(bookingId);
                dist/* toast.success */.Am.success("Booking cancelled successfully");
                fetchBooking(); // Refresh booking details
            } catch (error) {
                console.error("Error cancelling booking:", error);
                dist/* toast.error */.Am.error("Failed to cancel booking");
            } finally{
                setIsProcessing(false);
            }
        }
    };
    // Format date for display
    const formatDate = (dateString)=>{
        return (0,date_fns.format)(new Date(dateString), "MMMM d, yyyy");
    };
    // Loading state
    if (authStatus === "loading" || isLoading || !currentBooking) {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container mx-auto px-4 py-16",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "max-w-4xl mx-auto",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "animate-pulse space-y-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-8 bg-gray-200 rounded w-1/3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-64 bg-gray-200 rounded"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "space-y-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "h-4 bg-gray-200 rounded w-1/2"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "h-4 bg-gray-200 rounded w-3/4"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "h-4 bg-gray-200 rounded w-1/4"
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        });
    }
    // If booking not found or doesn't belong to the current user
    if (!currentBooking) {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container mx-auto px-4 py-16",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "max-w-4xl mx-auto text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-2xl font-semibold mb-4",
                            children: "Booking Not Found"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-gray-600 mb-6",
                            children: "The booking you are looking for does not exist or you don't have permission to view it."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/bookings",
                            className: "inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700",
                            children: "Back to My Bookings"
                        })
                    ]
                })
            })
        });
    }
    const booking = currentBooking;
    const paymentStatus = booking.payments?.[0]?.status || "UNKNOWN";
    // Variable used in conditions below
    const isUpcoming = new Date(booking.checkInDate) > new Date();
    // Const below would be used in UI conditions if needed
    // const isPast = new Date(booking.checkOutDate) < new Date();
    const canCancel = (booking.status === client_default.BookingStatus.PENDING || booking.status === client_default.BookingStatus.CONFIRMED) && isUpcoming;
    // Calculate nights
    const nights = Math.ceil((new Date(booking.checkOutDate).getTime() - new Date(booking.checkInDate).getTime()) / (1000 * 60 * 60 * 24));
    return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container mx-auto px-4 py-16",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "max-w-4xl mx-auto",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-between items-center mb-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-2xl font-semibold",
                                children: "Booking Details"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/bookings",
                                className: "text-blue-600 hover:text-blue-800",
                                children: "← Back to All Bookings"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `p-4 rounded-lg mb-8 ${booking.status === client_default.BookingStatus.CONFIRMED ? "bg-green-50 border border-green-200" : booking.status === client_default.BookingStatus.PENDING ? "bg-yellow-50 border border-yellow-200" : booking.status === client_default.BookingStatus.CANCELLED || booking.status === client_default.BookingStatus.REJECTED ? "bg-red-50 border border-red-200" : booking.status === client_default.BookingStatus.COMPLETED ? "bg-blue-50 border border-blue-200" : "bg-gray-50 border border-gray-200"}`,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center",
                            children: [
                                booking.status === client_default.BookingStatus.CONFIRMED && /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                    name: "FaCheckCircle"
                                }),
                                booking.status === client_default.BookingStatus.PENDING && /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                    name: "FaInfoCircle"
                                }),
                                (booking.status === client_default.BookingStatus.CANCELLED || booking.status === client_default.BookingStatus.REJECTED) && /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                    name: "FaTimesCircle"
                                }),
                                booking.status === client_default.BookingStatus.COMPLETED && /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                    name: "FaCheckCircle"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                            className: "font-medium",
                                            children: [
                                                booking.status === client_default.BookingStatus.CONFIRMED && "Booking Confirmed",
                                                booking.status === client_default.BookingStatus.PENDING && "Booking Pending",
                                                booking.status === client_default.BookingStatus.CANCELLED && "Booking Cancelled",
                                                booking.status === client_default.BookingStatus.REJECTED && "Booking Rejected",
                                                booking.status === client_default.BookingStatus.COMPLETED && "Stay Completed"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "text-sm",
                                            children: [
                                                booking.status === client_default.BookingStatus.CONFIRMED && "Your booking has been confirmed. You're all set for your stay!",
                                                booking.status === client_default.BookingStatus.PENDING && "Your booking is pending confirmation from the host.",
                                                booking.status === client_default.BookingStatus.CANCELLED && "This booking has been cancelled.",
                                                booking.status === client_default.BookingStatus.REJECTED && "Sorry, the host has rejected this booking request.",
                                                booking.status === client_default.BookingStatus.COMPLETED && "Your stay has been completed. We hope you had a great time!"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(bookings_BookingStatusTimeline, {
                        booking: booking
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-8 grid grid-cols-1 md:grid-cols-3 gap-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "md:col-span-2 space-y-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "bg-white rounded-lg shadow overflow-hidden",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "relative h-64 w-full",
                                            children: booking.property?.images?.[0]?.secureUrl ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: booking.property.images[0].secureUrl,
                                                alt: booking.property.title,
                                                fill: true,
                                                className: "object-cover"
                                            }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "w-full h-full bg-gray-200 flex items-center justify-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-gray-400",
                                                    children: "No image available"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "p-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "text-xl font-semibold mb-2",
                                                    children: booking.property?.title
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                    className: "flex items-center text-gray-600 mb-4",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                                            name: "FaMapMarkerAlt"
                                                        }),
                                                        booking.property?.address,
                                                        ", ",
                                                        booking.property?.city,
                                                        ", ",
                                                        booking.property?.country
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-100",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                                                    name: "FaCalendarAlt"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "font-medium",
                                                                            children: "Check-in"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-gray-600",
                                                                            children: formatDate(booking.checkInDate)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                                                    name: "FaCalendarAlt"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "font-medium",
                                                                            children: "Check-out"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-gray-600",
                                                                            children: formatDate(booking.checkOutDate)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                                                    name: "FaUsers"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "font-medium",
                                                                            children: "Guests"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                            className: "text-gray-600",
                                                                            children: [
                                                                                booking.numberOfGuests,
                                                                                " ",
                                                                                booking.numberOfGuests === 1 ? "guest" : "guests"
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(IconPlaceholder, {
                                                                    name: "FaMoneyBillWave"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "font-medium",
                                                                            children: "Duration"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                            className: "text-gray-600",
                                                                            children: [
                                                                                nights,
                                                                                " ",
                                                                                nights === 1 ? "night" : "nights"
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "mt-6 flex flex-wrap gap-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: `/properties/${booking.propertyId}`,
                                                            className: "px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700",
                                                            children: "View Property"
                                                        }),
                                                        canCancel && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            onClick: handleCancelBooking,
                                                            disabled: isProcessing,
                                                            className: `px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 ${isProcessing ? "opacity-50 cursor-not-allowed" : ""}`,
                                                            children: isProcessing ? "Processing..." : "Cancel Booking"
                                                        }),
                                                        booking.status === client_default.BookingStatus.COMPLETED && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: `/reviews/write?bookingId=${booking.id}`,
                                                            className: "px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700",
                                                            children: "Write a Review"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "md:col-span-1",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "bg-white rounded-lg shadow p-6 sticky top-8",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-lg font-semibold mb-4",
                                            children: "Price Details"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-3 border-b border-gray-100 pb-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                "$",
                                                                booking.property?.price,
                                                                " x ",
                                                                nights,
                                                                " nights"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                "$",
                                                                Number(booking.property?.price) * nights
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                booking.property?.cleaningFee && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex justify-between",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "Cleaning fee"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                "$",
                                                                booking.property.cleaningFee
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                booking.property?.serviceFee && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex justify-between",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "Service fee"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                "$",
                                                                booking.property.serviceFee
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex justify-between font-bold pt-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Total"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    children: [
                                                        "$",
                                                        booking.totalPrice
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mt-6 pt-4 border-t border-gray-100",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "font-medium mb-2",
                                                    children: "Payment Status"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: `p-2 rounded text-sm ${paymentStatus === client_default.PaymentStatus.COMPLETED ? "bg-green-100 text-green-800" : paymentStatus === client_default.PaymentStatus.PENDING ? "bg-yellow-100 text-yellow-800" : paymentStatus === client_default.PaymentStatus.REFUNDED ? "bg-blue-100 text-blue-800" : paymentStatus === client_default.PaymentStatus.FAILED ? "bg-red-100 text-red-800" : "bg-gray-100 text-gray-800"}`,
                                                    children: [
                                                        paymentStatus === client_default.PaymentStatus.COMPLETED && "Payment Complete",
                                                        paymentStatus === client_default.PaymentStatus.PENDING && "Payment Pending",
                                                        paymentStatus === client_default.PaymentStatus.REFUNDED && "Payment Refunded",
                                                        paymentStatus === client_default.PaymentStatus.FAILED && "Payment Failed",
                                                        paymentStatus === client_default.PaymentStatus.PARTIAL_REFUND && "Partial Refund Issued",
                                                        paymentStatus === "UNKNOWN" && "Payment Status Unknown"
                                                    ]
                                                }),
                                                booking.payments && booking.payments.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "mt-3 text-sm text-gray-600",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            children: [
                                                                "Payment Method: ",
                                                                booking.payments[0].provider
                                                            ]
                                                        }),
                                                        booking.payments[0].transactionId && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            className: "truncate",
                                                            children: [
                                                                "Transaction ID: ",
                                                                booking.payments[0].transactionId
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        booking.property?.owner && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mt-6 pt-4 border-t border-gray-100",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "font-medium mb-2",
                                                    children: "Host Information"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex items-center",
                                                    children: [
                                                        booking.property.owner.image ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: booking.property.owner.image,
                                                            alt: booking.property.owner.name || "Host",
                                                            width: 40,
                                                            height: 40,
                                                            className: "rounded-full"
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "text-gray-400 text-sm",
                                                                children: booking.property.owner.name?.charAt(0) || "H"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "ml-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    className: "font-medium",
                                                                    children: booking.property.owner.name
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: `/messages?host=${booking.property.owner.id}`,
                                                                    className: "text-sm text-blue-600 hover:text-blue-800",
                                                                    children: "Send a message"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 89092:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63296);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/bookings/[id]/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 64427:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(50515)


/***/ }),

/***/ 33533:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(49472)


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,4179,9633,9472,9658,5406,515,9091,153,3670,3999], () => (__webpack_exec__(69310)));
module.exports = __webpack_exports__;

})();