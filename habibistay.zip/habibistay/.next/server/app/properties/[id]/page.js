(() => {
var exports = {};
exports.id = 9562;
exports.ids = [9562];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 92761:
/***/ ((module) => {

"use strict";
module.exports = require("node:async_hooks");

/***/ }),

/***/ 17718:
/***/ ((module) => {

"use strict";
module.exports = require("node:child_process");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 15673:
/***/ ((module) => {

"use strict";
module.exports = require("node:events");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 93977:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 70612:
/***/ ((module) => {

"use strict";
module.exports = require("node:os");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 25997:
/***/ ((module) => {

"use strict";
module.exports = require("node:tty");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 63477:
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 51048:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79346);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68365);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82934);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48520);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(88991);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87042);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(90140);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(75266);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79421);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(61920);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(49408);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57258);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(81745);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'properties',
        {
        children: [
        '[id]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31590)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/properties/[id]/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64337)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/properties/[id]/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/properties/[id]/page"
  

/***/ }),

/***/ 55658:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34204))

/***/ }),

/***/ 34204:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ PropertyPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ../node_modules/next/navigation.js
var navigation = __webpack_require__(52865);
// EXTERNAL MODULE: ../node_modules/next-auth/react.js + 2 modules
var react = __webpack_require__(27258);
// EXTERNAL MODULE: ./src/components/layout/MainLayout.tsx + 1 modules
var MainLayout = __webpack_require__(93514);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(64427);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ../node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 5 modules
var AnimatePresence = __webpack_require__(47046);
// EXTERNAL MODULE: ../node_modules/framer-motion/dist/es/render/dom/motion.mjs + 192 modules
var motion = __webpack_require__(6616);
// EXTERNAL MODULE: ../node_modules/cloudinary/cloudinary.js
var cloudinary_cloudinary = __webpack_require__(76890);
;// CONCATENATED MODULE: ./src/lib/cloudinary.ts

// Stub environment variables for build
const env = {
    CLOUDINARY_CLOUD_NAME: "demo",
    CLOUDINARY_API_KEY: "123456789012345",
    CLOUDINARY_API_SECRET: "abcdefghijklmnopqrstuvwxyz"
};
// Configure Cloudinary with environment variables
cloudinary_cloudinary.v2.config({
    cloud_name: env.CLOUDINARY_CLOUD_NAME,
    api_key: env.CLOUDINARY_API_KEY,
    api_secret: env.CLOUDINARY_API_SECRET,
    secure: true
});
/**
 * Generate a Cloudinary URL with the specified transformations
 * @param publicId The public ID of the image in Cloudinary
 * @param options Transformation options
 * @returns Transformed image URL
 */ function getImageUrl(publicId, options = {}) {
    const { width , height , crop ="fill" , gravity ="auto" , quality ="auto" , format ="auto" , effect , radius , background , opacity , border , overlay , underlay , fetchFormat ="auto" , dpr ="auto" , aspectRatio  } = options;
    const transformations = [];
    // Add width and height if provided
    if (width) transformations.push(`w_${width}`);
    if (height) transformations.push(`h_${height}`);
    // Add other transformations
    if (crop) transformations.push(`c_${crop}`);
    if (gravity) transformations.push(`g_${gravity}`);
    if (quality) transformations.push(`q_${quality}`);
    if (format) transformations.push(`f_${format}`);
    if (effect) transformations.push(`e_${effect}`);
    if (radius !== undefined) transformations.push(`r_${radius}`);
    if (background) transformations.push(`b_${background}`);
    if (opacity !== undefined) transformations.push(`o_${opacity}`);
    if (border) transformations.push(`bo_${border}`);
    if (overlay) transformations.push(`l_${overlay}`);
    if (underlay) transformations.push(`u_${underlay}`);
    if (fetchFormat) transformations.push(`f_${fetchFormat}`);
    if (dpr) transformations.push(`dpr_${dpr}`);
    if (aspectRatio) transformations.push(`ar_${aspectRatio}`);
    // Generate the URL
    return cloudinary_cloudinary.v2.url(publicId, {
        transformation: [
            {
                ...transformations.length > 0 && {
                    transformation: transformations.join(",")
                }
            }
        ]
    });
}
/**
 * Generate a responsive image srcset for different screen sizes
 * @param publicId The public ID of the image in Cloudinary
 * @param options Base transformation options
 * @param breakpoints Array of breakpoints in pixels
 * @returns srcset string
 */ function getResponsiveSrcSet(publicId, options = {}, breakpoints = [
    640,
    768,
    1024,
    1280,
    1536
]) {
    return breakpoints.map((width)=>{
        const url = getImageUrl(publicId, {
            ...options,
            width
        });
        return `${url} ${width}w`;
    }).join(", ");
}
/**
 * Generate a blurred placeholder image URL
 * @param publicId The public ID of the image in Cloudinary
 * @param width Width of the placeholder
 * @param height Height of the placeholder
 * @returns Blurred placeholder URL
 */ function getBlurredPlaceholder(publicId, width = 100, height = 100) {
    return getImageUrl(publicId, {
        width,
        height,
        crop: "fill",
        quality: 1,
        effect: "blur:1000",
        fetchFormat: "auto"
    });
}
/* harmony default export */ const lib_cloudinary = ((/* unused pure expression or super */ null && (cloudinary)));

;// CONCATENATED MODULE: ./src/components/property/PropertyImageGallery.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



// Placeholder for heroicons
const XMarkIcon = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: className,
        children: "✕"
    });
const ChevronLeftIcon = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: className,
        children: "←"
    });
const ChevronRightIcon = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: className,
        children: "→"
    });

const variants = {
    enter: (direction)=>({
            x: direction > 0 ? 1000 : -1000,
            opacity: 0
        }),
    center: {
        x: 0,
        opacity: 1
    },
    exit: (direction)=>({
            x: direction < 0 ? 1000 : -1000,
            opacity: 0
        })
};
const swipeConfidenceThreshold = 10000;
const swipePower = (offset, velocity)=>{
    return Math.abs(offset) * velocity;
};
function PropertyImageGallery({ images , propertyId , className ="" , showThumbnails =true , autoPlay =false , showFullscreen =true , enableLightbox =true  }) {
    const [currentIndex, setCurrentIndex] = (0,react_.useState)(0);
    const [direction, setDirection] = (0,react_.useState)(0);
    const [isFullscreen, setIsFullscreen] = (0,react_.useState)(false);
    // Removed unused isLoading state
    const [isLightboxOpen, setIsLightboxOpen] = (0,react_.useState)(false);
    const intervalRef = (0,react_.useRef)();
    // Filter out any images without URLs
    const validImages = images.filter((img)=>img.url || img.secureUrl);
    // If no valid images, return null or a placeholder
    if (validImages.length === 0) {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `relative bg-gray-100 rounded-lg overflow-hidden ${className}`,
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "aspect-w-16 aspect-h-9 flex items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-gray-400",
                    children: "No images available"
                })
            })
        });
    }
    // Auto-play functionality
    (0,react_.useEffect)(()=>{
        if (autoPlay && validImages.length > 1) {
            intervalRef.current = setInterval(()=>{
                navigate(1);
            }, 5000);
        }
        // Always return cleanup function
        return ()=>{
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
    }, [
        autoPlay,
        validImages.length
    ]);
    // Pause auto-play on hover
    const handleMouseEnter = (0,react_.useCallback)(()=>{
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
        }
    }, []);
    const handleMouseLeave = (0,react_.useCallback)(()=>{
        if (autoPlay && validImages.length > 1) {
            intervalRef.current = setInterval(()=>{
                navigate(1);
            }, 5000);
        }
    }, [
        autoPlay,
        validImages.length
    ]);
    // Navigation functions
    const navigate = (0,react_.useCallback)((newDirection)=>{
        setDirection(newDirection);
        setCurrentIndex((prevIndex)=>{
            const nextIndex = prevIndex + newDirection;
            if (nextIndex >= validImages.length) {
                return 0;
            } else if (nextIndex < 0) {
                return validImages.length - 1;
            }
            return nextIndex;
        });
    }, [
        validImages.length
    ]);
    // Handle keyboard navigation
    (0,react_.useEffect)(()=>{
        if (!isLightboxOpen) return;
        const handleKeyDown = (e)=>{
            if (e.key === "Escape") {
                setIsLightboxOpen(false);
            } else if (e.key === "ArrowRight") {
                navigate(1);
            } else if (e.key === "ArrowLeft") {
                navigate(-1);
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return ()=>window.removeEventListener("keydown", handleKeyDown);
    }, [
        isLightboxOpen,
        navigate
    ]);
    // Handle fullscreen change
    (0,react_.useEffect)(()=>{
        const handleFullscreenChange = ()=>{
            setIsFullscreen(!!document.fullscreenElement);
        };
        document.addEventListener("fullscreenchange", handleFullscreenChange);
        return ()=>document.removeEventListener("fullscreenchange", handleFullscreenChange);
    }, []);
    // Toggle fullscreen
    const toggleFullscreen = (0,react_.useCallback)(()=>{
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(console.error);
        } else if (document.exitFullscreen) {
            document.exitFullscreen().catch(console.error);
        }
    }, []);
    // Get optimized image URL with Cloudinary transformations
    const getOptimizedImageUrl = (0,react_.useCallback)((image, options = {})=>{
        const publicId = image.url.split("/").pop()?.split(".")[0] || "";
        return getImageUrl(publicId, {
            width: 1200,
            height: 800,
            crop: "fill",
            quality: "auto",
            fetchFormat: "auto",
            ...options
        });
    }, []);
    const currentImage = validImages[currentIndex];
    const imageUrl = getOptimizedImageUrl(currentImage);
    const thumbnailSize = 80;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `relative ${className}`,
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        "data-property-id": propertyId,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative aspect-video bg-gray-100 rounded-lg overflow-hidden",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                        initial: false,
                        custom: direction,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                            custom: direction,
                            variants: variants,
                            initial: "enter",
                            animate: "center",
                            exit: "exit",
                            transition: {
                                x: {
                                    type: "spring",
                                    stiffness: 300,
                                    damping: 30
                                },
                                opacity: {
                                    duration: 0.2
                                }
                            },
                            drag: "x",
                            dragConstraints: {
                                left: 0,
                                right: 0
                            },
                            dragElastic: 1,
                            onDragEnd: (e, { offset , velocity  })=>{
                                const swipe = swipePower(offset.x, velocity.x);
                                if (swipe < -swipeConfidenceThreshold) {
                                    navigate(1);
                                } else if (swipe > swipeConfidenceThreshold) {
                                    navigate(-1);
                                }
                            },
                            className: "w-full h-full absolute inset-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: currentImage.secureUrl || currentImage.url,
                                alt: currentImage.caption || `Property image ${currentIndex + 1}`,
                                fill: true,
                                className: "object-cover",
                                priority: currentIndex === 0,
                                sizes: "(max-width: 768px) 100vw, 80vw",
                                onClick: ()=>enableLightbox && setIsLightboxOpen(true),
                                style: {
                                    cursor: enableLightbox ? "zoom-in" : "default"
                                }
                            })
                        }, currentIndex)
                    }),
                    validImages.length > 1 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    navigate(-1);
                                },
                                className: "absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors z-10",
                                "aria-label": "Previous image",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronLeftIcon, {
                                    className: "h-6 w-6"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    navigate(1);
                                },
                                className: "absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors z-10",
                                "aria-label": "Next image",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronRightIcon, {
                                    className: "h-6 w-6"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 text-white text-sm px-3 py-1 rounded-full z-10",
                        children: [
                            currentIndex + 1,
                            " / ",
                            validImages.length
                        ]
                    }),
                    showFullscreen && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: (e)=>{
                            e.stopPropagation();
                            toggleFullscreen();
                        },
                        className: "absolute bottom-4 right-4 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors z-10",
                        "aria-label": isFullscreen ? "Exit fullscreen" : "View fullscreen",
                        children: isFullscreen ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "h-5 w-5",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M6 18L18 6M6 6l12 12"
                            })
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "h-5 w-5",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0-4h-4m4 0l-5 5"
                            })
                        })
                    })
                ]
            }),
            showThumbnails && validImages.length > 1 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex gap-2 mt-2 overflow-x-auto pb-2",
                children: validImages.map((img, index)=>{
                    const thumbnailUrl = getOptimizedImageUrl(img, {
                        width: thumbnailSize,
                        height: thumbnailSize,
                        crop: "fill",
                        quality: "auto"
                    });
                    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>{
                            const newDirection = index > currentIndex ? 1 : -1;
                            setDirection(newDirection);
                            setCurrentIndex(index);
                        },
                        className: `flex-shrink-0 w-16 h-16 rounded-md overflow-hidden border-2 transition-all ${index === currentIndex ? "border-primary-500 ring-2 ring-primary-200" : "border-transparent hover:border-gray-300"}`,
                        "aria-label": `View image ${index + 1}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: img.secureUrl || img.url,
                            alt: "",
                            width: thumbnailSize,
                            height: thumbnailSize,
                            className: "w-full h-full object-cover"
                        })
                    }, img.id);
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                children: isLightboxOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    className: "fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4",
                    onClick: ()=>setIsLightboxOpen(false),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "absolute top-4 right-4 text-white hover:text-gray-300 z-10",
                            onClick: (e)=>{
                                e.stopPropagation();
                                setIsLightboxOpen(false);
                            },
                            "aria-label": "Close lightbox",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(XMarkIcon, {
                                className: "h-8 w-8"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "relative w-full max-w-6xl h-full max-h-[90vh]",
                            onClick: (e)=>e.stopPropagation(),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                                    initial: false,
                                    custom: direction,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                        custom: direction,
                                        variants: variants,
                                        initial: "enter",
                                        animate: "center",
                                        exit: "exit",
                                        transition: {
                                            x: {
                                                type: "spring",
                                                stiffness: 300,
                                                damping: 30
                                            },
                                            opacity: {
                                                duration: 0.2
                                            }
                                        },
                                        className: "w-full h-full absolute inset-0",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: currentImage.secureUrl || currentImage.url,
                                            alt: currentImage.caption || `Property image ${currentIndex + 1}`,
                                            fill: true,
                                            className: "object-contain",
                                            priority: true,
                                            sizes: "90vw"
                                        })
                                    }, currentIndex)
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: (e)=>{
                                        e.stopPropagation();
                                        navigate(-1);
                                    },
                                    className: "absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 text-white p-3 rounded-full hover:bg-black/70 transition-colors z-10",
                                    "aria-label": "Previous image",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronLeftIcon, {
                                        className: "h-8 w-8"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: (e)=>{
                                        e.stopPropagation();
                                        navigate(1);
                                    },
                                    className: "absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 text-white p-3 rounded-full hover:bg-black/70 transition-colors z-10",
                                    "aria-label": "Next image",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronRightIcon, {
                                        className: "h-8 w-8"
                                    })
                                }),
                                currentImage.caption && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 text-white text-sm",
                                    children: currentImage.caption
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "absolute top-4 left-1/2 -translate-x-1/2 bg-black/50 text-white text-sm px-3 py-1 rounded-full",
                                    children: [
                                        currentIndex + 1,
                                        " / ",
                                        validImages.length
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ../node_modules/date-fns/index.js
var date_fns = __webpack_require__(58525);
// EXTERNAL MODULE: ../node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(35562);
// EXTERNAL MODULE: ./src/hooks/usePropertyAvailability.ts
var usePropertyAvailability = __webpack_require__(29554);
// EXTERNAL MODULE: ./src/hooks/useBookings.ts
var useBookings = __webpack_require__(73999);
// EXTERNAL MODULE: ./src/hooks/usePayments.ts
var usePayments = __webpack_require__(26173);
;// CONCATENATED MODULE: ./src/components/property/BookingForm.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








// Placeholder for date picker component
// import DatePicker from 'react-datepicker';
// import 'react-datepicker/dist/react-datepicker.css';
// Simplified DatePicker component
const DatePicker = ({ selected , onChange , minDate , maxDate , // dateFormat, // Removed unused parameter
placeholderText , className , required , disabled  })=>/*#__PURE__*/ jsx_runtime_.jsx("input", {
        type: "date",
        value: selected ? (0,date_fns.format)(selected, "yyyy-MM-dd") : "",
        onChange: (e)=>{
            if (e.target.value) {
                onChange(new Date(e.target.value));
            } else {
                onChange(null);
            }
        },
        min: minDate ? (0,date_fns.format)(minDate, "yyyy-MM-dd") : undefined,
        max: maxDate ? (0,date_fns.format)(maxDate, "yyyy-MM-dd") : undefined,
        placeholder: placeholderText,
        className: className,
        required: required,
        disabled: disabled
    });
function BookingForm({ property , className =""  }) {
    const router = (0,navigation.useRouter)();
    const { data: session  } = (0,react/* useSession */.kP)();
    const { getAvailability , checkAvailabilityForBooking , calculateBookingPrice  } = (0,usePropertyAvailability/* usePropertyAvailability */.g)();
    const { createBooking  } = (0,useBookings/* useBookings */.o)();
    const { initializePayment  } = (0,usePayments/* usePayments */.I)();
    // Form state
    const [checkInDate, setCheckInDate] = (0,react_.useState)(null);
    const [checkOutDate, setCheckOutDate] = (0,react_.useState)(null);
    const [guests, setGuests] = (0,react_.useState)(1);
    const [isCheckingAvailability, setIsCheckingAvailability] = (0,react_.useState)(false);
    const [isBooking, setIsBooking] = (0,react_.useState)(false);
    const [availabilityChecked, setAvailabilityChecked] = (0,react_.useState)(false);
    const [isAvailable, setIsAvailable] = (0,react_.useState)(false);
    // Price calculation state
    const [basePrice, setBasePrice] = (0,react_.useState)(property.price);
    const [cleaningFee] = (0,react_.useState)(property.cleaningFee || 0);
    const [serviceFee] = (0,react_.useState)(property.serviceFee || 0);
    const [totalNights, setTotalNights] = (0,react_.useState)(0);
    const [nightsPrice, setNightsPrice] = (0,react_.useState)(0);
    const [totalPrice, setTotalPrice] = (0,react_.useState)(0);
    // Calculate min and max dates for the date picker
    const today = new Date();
    const maxDate = new Date();
    maxDate.setFullYear(maxDate.getFullYear() + 1);
    // When dates change, check availability and update prices
    (0,react_.useEffect)(()=>{
        if (checkInDate && checkOutDate) {
            // Calculate nights
            const nights = (0,date_fns.differenceInDays)(checkOutDate, checkInDate);
            setTotalNights(nights);
            // Reset availability check
            setAvailabilityChecked(false);
            setIsAvailable(false);
            // Format dates for API
            const checkInStr = (0,date_fns.format)(checkInDate, "yyyy-MM-dd");
            const checkOutStr = (0,date_fns.format)(checkOutDate, "yyyy-MM-dd");
            // Get availability and calculate price
            const loadAvailability = async ()=>{
                setIsCheckingAvailability(true);
                try {
                    const availabilityData = await getAvailability(property.id, checkInStr, checkOutStr);
                    if (availabilityData) {
                        // Calculate price based on availability data
                        const priceCalculation = calculateBookingPrice(checkInStr, checkOutStr, availabilityData.availability);
                        setBasePrice(availabilityData.basePrice);
                        setNightsPrice(priceCalculation.totalPrice);
                        setTotalPrice(priceCalculation.totalPrice + cleaningFee + serviceFee);
                        // Check if all dates are available
                        const { isAvailable  } = await checkAvailabilityForBooking(property.id, checkInStr, checkOutStr);
                        setIsAvailable(isAvailable);
                        setAvailabilityChecked(true);
                    }
                } catch (error) {
                    console.error("Error checking availability:", error);
                    dist/* toast.error */.Am.error("Error checking availability. Please try again.");
                } finally{
                    setIsCheckingAvailability(false);
                }
            };
            loadAvailability();
        } else {
            // Reset when dates are cleared
            setTotalNights(0);
            setNightsPrice(0);
            setTotalPrice(0);
            setAvailabilityChecked(false);
            setIsAvailable(false);
        }
    }, [
        checkInDate,
        checkOutDate,
        property.id,
        getAvailability,
        checkAvailabilityForBooking,
        calculateBookingPrice,
        cleaningFee,
        serviceFee
    ]);
    // Handle booking request
    const handleBooking = async ()=>{
        if (!session) {
            // Redirect to login if not authenticated
            dist/* toast.error */.Am.error("Please sign in to book this property");
            router.push("/login");
            return;
        }
        if (!checkInDate || !checkOutDate) {
            dist/* toast.error */.Am.error("Please select check-in and check-out dates");
            return;
        }
        if (!isAvailable) {
            dist/* toast.error */.Am.error("This property is not available for the selected dates");
            return;
        }
        setIsBooking(true);
        try {
            // Format dates for API
            const checkInStr = (0,date_fns.format)(checkInDate, "yyyy-MM-dd");
            const checkOutStr = (0,date_fns.format)(checkOutDate, "yyyy-MM-dd");
            // Create booking
            const booking = await createBooking({
                propertyId: property.id,
                checkInDate: checkInStr,
                checkOutDate: checkOutStr,
                numberOfGuests: guests
            });
            if (booking) {
                // Initialize payment
                const paymentInit = await initializePayment(booking.id);
                if (paymentInit) {
                    // Redirect to checkout page with booking and payment info
                    router.push(`/checkout?bookingId=${booking.id}&paymentId=${paymentInit.paymentId}`);
                } else {
                    dist/* toast.error */.Am.error("Error initializing payment. Please try again.");
                }
            }
        } catch (error) {
            console.error("Error creating booking:", error);
            dist/* toast.error */.Am.error("Error creating booking. Please try again.");
        } finally{
            setIsBooking(false);
        }
    };
    // Generate guest options
    const guestOptions = [];
    for(let i = 1; i <= property.maxGuests; i++){
        guestOptions.push(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("option", {
            value: i,
            children: [
                i,
                " ",
                i === 1 ? "guest" : "guests"
            ]
        }, i));
    }
    // Custom day renderer removed as it's not used
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `bg-white rounded-xl shadow-md overflow-hidden ${className}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "p-6",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between items-start mb-4",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "text-2xl font-bold",
                                    children: [
                                        "$",
                                        basePrice
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-gray-600",
                                    children: " night"
                                })
                            ]
                        }),
                        availabilityChecked && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `text-sm font-medium ${isAvailable ? "text-green-600" : "text-red-600"}`,
                            children: isAvailable ? "Available" : "Unavailable"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    className: "space-y-4",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid grid-cols-2 gap-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            className: "block text-sm font-medium text-gray-700 mb-1",
                                            children: "Check-in"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(DatePicker, {
                                            selected: checkInDate,
                                            onChange: (date)=>{
                                                setCheckInDate(date);
                                                // If checkout date is earlier than checkin, reset it
                                                if (checkOutDate && date && date >= checkOutDate) {
                                                    setCheckOutDate((0,date_fns.addDays)(date, 1));
                                                }
                                            },
                                            minDate: today,
                                            maxDate: maxDate,
                                            dateFormat: "yyyy-MM-dd",
                                            placeholderText: "Select date",
                                            className: "w-full p-2 border border-gray-300 rounded-md",
                                            required: true,
                                            disabled: isCheckingAvailability || isBooking
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            className: "block text-sm font-medium text-gray-700 mb-1",
                                            children: "Check-out"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(DatePicker, {
                                            selected: checkOutDate,
                                            onChange: (date)=>setCheckOutDate(date),
                                            minDate: checkInDate ? (0,date_fns.addDays)(checkInDate, 1) : (0,date_fns.addDays)(today, 1),
                                            maxDate: maxDate,
                                            dateFormat: "yyyy-MM-dd",
                                            placeholderText: "Select date",
                                            className: "w-full p-2 border border-gray-300 rounded-md",
                                            required: true,
                                            disabled: !checkInDate || isCheckingAvailability || isBooking
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    className: "block text-sm font-medium text-gray-700 mb-1",
                                    children: "Guests"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                    className: "w-full p-2 border border-gray-300 rounded-md",
                                    value: guests,
                                    onChange: (e)=>setGuests(Number(e.target.value)),
                                    disabled: isBooking,
                                    children: guestOptions
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "button",
                            className: `w-full py-3 rounded-md font-medium transition-colors ${isBooking || isCheckingAvailability || !availabilityChecked || !isAvailable ? "bg-blue-400 cursor-not-allowed text-white" : "bg-blue-600 hover:bg-blue-700 text-white"}`,
                            onClick: handleBooking,
                            disabled: isBooking || isCheckingAvailability || !availabilityChecked || !isAvailable,
                            children: isBooking ? "Booking..." : isCheckingAvailability ? "Checking..." : "Book now"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-center text-sm text-gray-500",
                            children: "You won't be charged yet"
                        }),
                        totalNights > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-2 pt-4 border-t border-gray-200",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-between",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "text-gray-600",
                                            children: [
                                                "$",
                                                basePrice,
                                                " x ",
                                                totalNights,
                                                " ",
                                                totalNights === 1 ? "night" : "nights"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                "$",
                                                nightsPrice
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-between",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-gray-600",
                                            children: "Cleaning fee"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                "$",
                                                cleaningFee
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-between",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-gray-600",
                                            children: "Service fee"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                "$",
                                                serviceFee
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-between pt-4 border-t border-gray-300 font-bold",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: "Total"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                "$",
                                                totalPrice
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/app/properties/[id]/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


// Removing unused import: import Link from 'next/link';





const Icon = ({ name , className ="" , size =5  })=>{
    const sizeClass = `w-${size} h-${size}`;
    const icons = {
        "map-marker": "\uD83D\uDCCD",
        "star": "★",
        "star-o": "☆",
        "star-half": "\xbd",
        "info-circle": "ⓘ",
        "share": "↗️"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: `inline-block ${sizeClass} ${className}`,
        children: icons[name]
    });
};
// Star rating component with safe icon rendering
const StarRating = ({ rating  })=>{
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    // Create star elements with safe fallbacks
    for(let i = 0; i < fullStars; i++){
        stars.push(/*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "text-yellow-400",
            children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                name: "star",
                className: "text-yellow-400"
            })
        }, `full-${i}`));
    }
    if (hasHalfStar) {
        stars.push(/*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "text-yellow-400",
            children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                name: "star-half",
                className: "text-yellow-400"
            })
        }, "half"));
    }
    for(let i = 0; i < emptyStars; i++){
        stars.push(/*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "text-gray-300",
            children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                name: "star-o",
                className: "text-gray-300"
            })
        }, `empty-${i}`));
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex space-x-1",
        children: stars
    });
};
// Property details page
function PropertyPage() {
    const params = (0,navigation.useParams)();
    const router = (0,navigation.useRouter)();
    const propertyId = Array.isArray(params?.id) ? params.id[0] : params?.id || "";
    const [isSaved, setIsSaved] = (0,react_.useState)(false);
    const [isLoading, setIsLoading] = (0,react_.useState)(true);
    const [property, setProperty] = (0,react_.useState)(null);
    const {} = (0,react/* useSession */.kP)(); // Keep session hook for auth state
    (0,react_.useEffect)(()=>{
        // Function to fetch property data
        const fetchProperty = async ()=>{
            try {
                // In a real implementation, this would be an API call
                // For now, let's simulate a fetch with mock data
                const response = await fetch(`/api/properties/${propertyId}`);
                if (!response.ok) {
                    if (response.status === 404) {
                        setProperty(null);
                    } else {
                        throw new Error("Failed to fetch property");
                    }
                } else {
                    const data = await response.json();
                    setProperty(data);
                }
            } catch (error) {
                console.error("Error fetching property:", error);
                dist/* toast.error */.Am.error("Failed to load property data");
            } finally{
                setIsLoading(false);
            }
        };
        if (propertyId) {
            fetchProperty();
        }
    }, [
        propertyId
    ]);
    // Mock property data for demonstration (until real API endpoint is integrated)
    (0,react_.useEffect)(()=>{
        if (isLoading && !property) {
            // This is temporary mock data until we have a real API
            setTimeout(()=>{
                setProperty({
                    id: propertyId,
                    title: "Luxury Beach Villa",
                    description: "Stunning beachfront villa with panoramic ocean views and private pool. This spacious property features modern amenities, direct beach access, and is perfect for family vacations or special gatherings. Enjoy breathtaking sunsets from your private terrace and fall asleep to the sound of waves.",
                    address: "123 Beach Road",
                    city: "Miami",
                    country: "USA",
                    price: 299,
                    cleaningFee: 150,
                    serviceFee: 50,
                    rating: 4.9,
                    reviews: [
                        {
                            id: 1,
                            user: {
                                name: "John Smith",
                                image: "/images/user1.jpg"
                            },
                            rating: 5,
                            date: "2025-04-15",
                            comment: "Amazing property with stunning views. The host was very responsive and accommodating. Would definitely stay here again!"
                        },
                        {
                            id: 2,
                            user: {
                                name: "Sarah Johnson",
                                image: "/images/user2.jpg"
                            },
                            rating: 4,
                            date: "2025-03-22",
                            comment: "Beautiful villa, great location. The only issue was the air conditioning in one of the bedrooms wasn't working properly, but the host quickly sent someone to fix it."
                        },
                        {
                            id: 3,
                            user: {
                                name: "Michael Brown",
                                image: "/images/user3.jpg"
                            },
                            rating: 5,
                            date: "2025-02-10",
                            comment: "Perfect vacation spot! The villa is exactly as pictured, and the beach access is incredible. Kitchen was well-stocked and the beds were very comfortable."
                        }
                    ],
                    images: [
                        {
                            id: "1",
                            url: "https://res.cloudinary.com/demo/image/upload/v1312461204/sample.jpg",
                            secureUrl: "https://res.cloudinary.com/demo/image/upload/v1312461204/sample.jpg",
                            isPrimary: true,
                            caption: null,
                            width: 1200,
                            height: 800
                        },
                        {
                            id: "2",
                            url: "https://res.cloudinary.com/demo/image/upload/v1312461204/sample.jpg",
                            secureUrl: "https://res.cloudinary.com/demo/image/upload/v1312461204/sample.jpg",
                            isPrimary: false,
                            caption: null,
                            width: 1200,
                            height: 800
                        }
                    ],
                    amenities: [
                        "WiFi",
                        "Pool",
                        "Parking",
                        "Air Conditioning",
                        "TV",
                        "Kitchen",
                        "Washer/Dryer",
                        "Beach Access",
                        "Balcony",
                        "BBQ Grill"
                    ],
                    bedrooms: 4,
                    bathrooms: 3,
                    maxGuests: 8,
                    beds: 4,
                    host: {
                        name: "John Doe",
                        avatar: "/images/host-avatar.jpg",
                        isSuperhost: true,
                        joinDate: "2020-05-15"
                    },
                    houseRules: [
                        {
                            id: 1,
                            rule: "No smoking",
                            icon: "no-smoking"
                        },
                        {
                            id: 2,
                            rule: "No parties or events",
                            icon: "party"
                        },
                        {
                            id: 3,
                            rule: "Check-in after 3:00 PM",
                            icon: "check-in"
                        },
                        {
                            id: 4,
                            rule: "Checkout before 11:00 AM",
                            icon: "check-out"
                        }
                    ],
                    checkInTime: "3:00 PM",
                    checkOutTime: "11:00 AM",
                    propertyType: "Entire villa"
                });
                setIsLoading(false);
            }, 1000);
        }
    }, [
        isLoading,
        propertyId,
        property
    ]);
    // Handle save property
    const handleSaveProperty = (e)=>{
        e.preventDefault();
        setIsSaved(!isSaved);
        (0,dist/* toast */.Am)(isSaved ? "Removed from saved properties" : "Property saved to your wishlist!");
    };
    if (isLoading) {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container mx-auto px-4 py-8",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "animate-pulse space-y-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-8 bg-gray-200 rounded w-1/3"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-4 bg-gray-200 rounded w-1/4"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-[500px] bg-gray-200 rounded"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid grid-cols-1 md:grid-cols-3 gap-8 mt-8",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "md:col-span-2 space-y-6",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-gray-200 h-64 rounded"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-gray-200 h-64 rounded"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-gray-200 h-96 rounded"
                                })
                            ]
                        })
                    ]
                })
            })
        });
    }
    if (!property) {
        return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto px-4 py-8 text-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-2xl font-bold text-gray-800",
                        children: "Property not found"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>router.push("/search"),
                        className: "text-blue-500 hover:underline mt-4 inline-block bg-transparent border-none cursor-pointer p-0",
                        children: "Browse Properties"
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(MainLayout/* default */.Z, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container mx-auto px-4 py-8",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mb-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-3xl font-bold text-gray-900",
                            children: property.title
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-wrap items-center justify-between mt-2",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center mr-6 mt-2",
                                    children: [
                                        property.rating && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center text-gray-700",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                    name: "star",
                                                    className: "text-yellow-500 mr-1",
                                                    size: 4
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: property.rating.toFixed(1)
                                                }),
                                                property.reviews && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "mx-1",
                                                            children: "\xb7"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                property.reviews.length,
                                                                " reviews"
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "mx-2",
                                            children: "•"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center text-gray-700",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                    name: "map-marker",
                                                    className: "text-gray-500 mr-2",
                                                    size: 4
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    children: [
                                                        property.city,
                                                        ", ",
                                                        property.country
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex space-x-4 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                            onClick: ()=>{
                                                if (navigator.share) {
                                                    navigator.share({
                                                        title: property.title,
                                                        text: `Check out this property in ${property.city}, ${property.country}`,
                                                        url: window.location.href
                                                    }).catch(console.error);
                                                } else {
                                                    // Fallback for browsers that don't support Web Share API
                                                    navigator.clipboard.writeText(window.location.href);
                                                    dist/* toast.success */.Am.success("Link copied to clipboard!");
                                                }
                                            },
                                            className: "flex items-center text-gray-700 hover:text-gray-900",
                                            "aria-label": "Share property",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                    name: "share",
                                                    className: "text-gray-500 mr-1",
                                                    size: 4
                                                }),
                                                "Share"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                            onClick: handleSaveProperty,
                                            className: `flex items-center ${isSaved ? "text-red-500" : "text-gray-700 hover:text-gray-900"}`,
                                            "aria-label": isSaved ? "Remove from saved" : "Save property",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    className: "h-5 w-5 mr-1",
                                                    fill: isSaved ? "currentColor" : "none",
                                                    viewBox: "0 0 24 24",
                                                    stroke: "currentColor",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        strokeWidth: 2,
                                                        d: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                                                    })
                                                }),
                                                isSaved ? "Saved" : "Save"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mb-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(PropertyImageGallery, {
                        images: property.images,
                        propertyId: property.id
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col md:flex-row gap-8",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "md:w-2/3",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "bg-white rounded-lg shadow-sm p-6 mb-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center justify-between mb-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "text-2xl font-semibold",
                                                    children: property.title
                                                }),
                                                property.rating && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                            name: "star",
                                                            className: "text-yellow-500 mr-1",
                                                            size: 4
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-semibold",
                                                            children: property.rating.toFixed(1)
                                                        }),
                                                        property.reviews && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "text-gray-500 ml-1",
                                                            children: [
                                                                "(",
                                                                property.reviews.length,
                                                                ")"
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "border-t border-b border-gray-100 py-6 my-6",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "grid grid-cols-2 md:grid-cols-4 gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "text-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text-gray-500 text-sm",
                                                                children: "Bedrooms"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "font-medium",
                                                                children: property.bedrooms
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "text-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text-gray-500 text-sm",
                                                                children: "Bathrooms"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "font-medium",
                                                                children: property.bathrooms
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "text-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text-gray-500 text-sm",
                                                                children: "Guests"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "font-medium",
                                                                children: property.maxGuests
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "text-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text-gray-500 text-sm",
                                                                children: "Beds"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "font-medium",
                                                                children: property.beds
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mb-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "text-lg font-semibold mb-3",
                                                    children: "About this property"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-gray-700",
                                                    children: property.description
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mb-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "text-lg font-semibold mb-3",
                                                    children: "Amenities"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                                    children: property.amenities.map((amenity, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                                    className: "h-5 w-5 text-green-500 mr-2",
                                                                    fill: "none",
                                                                    viewBox: "0 0 24 24",
                                                                    stroke: "currentColor",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: 2,
                                                                        d: "M5 13l4 4L19 7"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    children: amenity
                                                                })
                                                            ]
                                                        }, index))
                                                })
                                            ]
                                        }),
                                        property.houseRules && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "text-lg font-semibold mb-3",
                                                    children: "House rules"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "space-y-2",
                                                    children: property.houseRules.map((rule)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-gray-500 mr-2",
                                                                    children: "•"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    children: rule.rule
                                                                })
                                                            ]
                                                        }, rule.id))
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                property.reviews && property.reviews.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "bg-white rounded-lg shadow-sm p-6 mb-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                            className: "text-2xl font-semibold mb-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                    name: "star",
                                                    className: "text-yellow-500 mr-1",
                                                    size: 4
                                                }),
                                                property.rating?.toFixed(1),
                                                " \xb7 ",
                                                property.reviews.length,
                                                " reviews"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "space-y-8",
                                            children: property.reviews.map((review)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "border-b border-gray-100 pb-6 last:border-0 last:pb-0",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-medium",
                                                                    children: review.user.name.charAt(0)
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "ml-3",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: "font-medium",
                                                                            children: review.user.name
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: "text-sm text-gray-500",
                                                                            children: review.date
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "mb-2",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(StarRating, {
                                                                rating: review.rating
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "text-gray-700",
                                                            children: review.comment
                                                        })
                                                    ]
                                                }, review.id))
                                        })
                                    ]
                                }),
                                property.host && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "bg-white rounded-lg shadow-sm p-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-start",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "h-16 w-16 rounded-full bg-gray-200 flex items-center justify-center text-2xl text-gray-500 font-medium",
                                                    children: property.host.name.charAt(0)
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "ml-4",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                                            className: "text-lg font-semibold",
                                                            children: [
                                                                "Hosted by ",
                                                                property.host.name
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            className: "text-gray-500 text-sm mt-1",
                                                            children: [
                                                                "Joined in ",
                                                                property.host.joinDate
                                                            ]
                                                        }),
                                                        property.host.isSuperhost && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                                    name: "star",
                                                                    className: "mr-1",
                                                                    size: 3
                                                                }),
                                                                "Superhost"
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mt-6 pt-6 border-t border-gray-100",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "font-medium mb-2",
                                                    children: "During your stay"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-gray-600 text-sm",
                                                    children: "I'm happy to help with anything you need during your stay. Don't hesitate to reach out if you have any questions or need recommendations!"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mt-6 pt-6 border-t border-gray-100",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "font-medium mb-2",
                                                    children: "Response rate: 100%"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-gray-600 text-sm",
                                                    children: "Typically responds within an hour"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "mt-6 w-full bg-white border border-gray-300 rounded-md py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500",
                                            children: "Contact host"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "md:w-1/3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(BookingForm, {
                                property: {
                                    id: property.id,
                                    title: property.title,
                                    price: property.price,
                                    cleaningFee: property.cleaningFee,
                                    serviceFee: property.serviceFee,
                                    maxGuests: property.maxGuests
                                }
                            })
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 31590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63296);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/properties/[id]/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,4179,9633,9472,9658,5406,515,3310,9091,153,3670,3999,6173,9554], () => (__webpack_exec__(51048)));
module.exports = __webpack_exports__;

})();