(() => {
var exports = {};
exports.id = 1931;
exports.ids = [1931];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 92761:
/***/ ((module) => {

"use strict";
module.exports = require("node:async_hooks");

/***/ }),

/***/ 17718:
/***/ ((module) => {

"use strict";
module.exports = require("node:child_process");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 15673:
/***/ ((module) => {

"use strict";
module.exports = require("node:events");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 93977:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 70612:
/***/ ((module) => {

"use strict";
module.exports = require("node:os");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 25997:
/***/ ((module) => {

"use strict";
module.exports = require("node:tty");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 51448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79346);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68365);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82934);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48520);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(88991);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87042);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(90140);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(75266);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79421);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(61920);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(49408);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57258);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(81745);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95577)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64337)), "/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/app/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 57907:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 38372, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 40600, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1275, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 18719, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50822, 23))

/***/ }),

/***/ 26487:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 49472, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50515, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 153))

/***/ }),

/***/ 95577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HomePage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ../node_modules/next/link.js
var next_link = __webpack_require__(83646);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(14098);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ../node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(70610);
// EXTERNAL MODULE: ../node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(63296);
;// CONCATENATED MODULE: ./src/components/layout/Navbar.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/habibistay/src/components/layout/Navbar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Navbar = (__default__);
;// CONCATENATED MODULE: ./src/components/layout/Footer.tsx


// Placeholder icon components since we're having issues with react-icons
const IconComponent = ({ size =20 , children  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: "inline-block",
        style: {
            width: `${size}px`,
            height: `${size}px`
        },
        children: children
    });
const FaFacebook = ({ size  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        size: size,
        children: "\uD83D\uDCD8"
    });
const FaTwitter = ({ size  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        size: size,
        children: "\uD83D\uDC26"
    });
const FaInstagram = ({ size  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        size: size,
        children: "\uD83D\uDCF7"
    });
const FaLinkedin = ({ size  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        size: size,
        children: "\uD83D\uDCBC"
    });
const Footer = ()=>{
    const currentYear = new Date().getFullYear();
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "bg-gray-800 text-white",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 md:grid-cols-4 gap-8",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-lg font-semibold mb-4",
                                    children: "Habibistay"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-gray-300 text-sm",
                                    children: "Find and book unique accommodations around the world. Experience the comfort of home wherever you go."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-4 flex space-x-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "https://facebook.com",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "text-gray-400 hover:text-white",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FaFacebook, {
                                                size: 20
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "https://twitter.com",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "text-gray-400 hover:text-white",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FaTwitter, {
                                                size: 20
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "https://instagram.com",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "text-gray-400 hover:text-white",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FaInstagram, {
                                                size: 20
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "https://linkedin.com",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "text-gray-400 hover:text-white",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FaLinkedin, {
                                                size: 20
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-lg font-semibold mb-4",
                                    children: "Discover"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "space-y-2 text-gray-300 text-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/search",
                                                className: "hover:text-white",
                                                children: "Search Properties"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/cities",
                                                className: "hover:text-white",
                                                children: "Cities"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/categories",
                                                className: "hover:text-white",
                                                children: "Categories"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/experiences",
                                                className: "hover:text-white",
                                                children: "Experiences"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-lg font-semibold mb-4",
                                    children: "Hosting"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "space-y-2 text-gray-300 text-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/host",
                                                className: "hover:text-white",
                                                children: "Become a Host"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/host/resources",
                                                className: "hover:text-white",
                                                children: "Resources"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/host/community",
                                                className: "hover:text-white",
                                                children: "Community"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/host/responsible-hosting",
                                                className: "hover:text-white",
                                                children: "Responsible Hosting"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-lg font-semibold mb-4",
                                    children: "Support"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "space-y-2 text-gray-300 text-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/help",
                                                className: "hover:text-white",
                                                children: "Help Center"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/contact",
                                                className: "hover:text-white",
                                                children: "Contact Us"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/cancellation-options",
                                                className: "hover:text-white",
                                                children: "Cancellation Options"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/safety",
                                                className: "hover:text-white",
                                                children: "Safety Information"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt-12 pt-8 border-t border-gray-700 flex flex-col md:flex-row justify-between items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-gray-300 text-sm",
                            children: [
                                "\xa9 ",
                                currentYear,
                                " Habibistay. All rights reserved."
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-4 md:mt-0 flex flex-wrap gap-4 text-sm text-gray-300",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/terms",
                                    className: "hover:text-white",
                                    children: "Terms of Service"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/privacy",
                                    className: "hover:text-white",
                                    children: "Privacy Policy"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/cookies",
                                    className: "hover:text-white",
                                    children: "Cookie Policy"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/sitemap",
                                    className: "hover:text-white",
                                    children: "Sitemap"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const layout_Footer = (Footer);

;// CONCATENATED MODULE: ./src/components/layout/MainLayout.tsx




const MainLayout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col min-h-screen",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "flex-grow",
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layout_Footer, {})
        ]
    });
};
/* harmony default export */ const layout_MainLayout = (MainLayout);

;// CONCATENATED MODULE: ./src/app/page.tsx




// Placeholder for react-icons
const FaSearch = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: className || "",
        children: "\uD83D\uDD0D"
    });
const FaMapMarkerAlt = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: className || "",
        children: "\uD83D\uDCCD"
    });
const FaCalendarAlt = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: className || "",
        children: "\uD83D\uDCC5"
    });
const FaUser = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: className || "",
        children: "\uD83D\uDC64"
    });
// Hero section with search functionality
const HeroSection = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative h-[600px] w-full",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute inset-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/images/hero-image.jpg",
                        alt: "Beautiful vacation rental",
                        fill: true,
                        priority: true,
                        className: "object-cover"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "absolute inset-0 bg-black bg-opacity-40"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative flex flex-col items-center justify-center h-full text-white px-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-4xl md:text-5xl font-bold mb-4 text-center",
                        children: "Find Your Perfect Stay with Habibistay"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-xl md:text-2xl mb-8 text-center max-w-3xl",
                        children: "Discover unique accommodations and experiences around the world"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full max-w-4xl bg-white rounded-lg shadow-lg p-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-1 md:grid-cols-4 gap-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaMapMarkerAlt, {
                                                    className: "text-gray-400"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "text",
                                                placeholder: "Where are you going?",
                                                className: "pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-[#2957c3] focus:ring-[#2957c3]"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaCalendarAlt, {
                                                    className: "text-gray-400"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "text",
                                                placeholder: "Check in",
                                                className: "pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-[#2957c3] focus:ring-[#2957c3]"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaCalendarAlt, {
                                                    className: "text-gray-400"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "text",
                                                placeholder: "Check out",
                                                className: "pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-[#2957c3] focus:ring-[#2957c3]"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(FaUser, {
                                                    className: "text-gray-400"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "text",
                                                placeholder: "Guests",
                                                className: "pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-[#2957c3] focus:ring-[#2957c3]"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-4",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/search",
                                    className: "w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#2957c3] hover:bg-[#1e3c8a] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2957c3]",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(FaSearch, {
                                            className: "mr-2"
                                        }),
                                        " Search"
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
// Featured properties section
const FeaturedProperties = ()=>{
    // Mock data for featured properties
    const featuredProperties = [
        {
            id: 1,
            title: "Luxury Beach Villa",
            location: "Miami, Florida",
            price: 299,
            rating: 4.9,
            reviews: 128,
            image: "/images/property-1.jpg"
        },
        {
            id: 2,
            title: "Mountain Retreat Cabin",
            location: "Aspen, Colorado",
            price: 189,
            rating: 4.8,
            reviews: 95,
            image: "/images/property-2.jpg"
        },
        {
            id: 3,
            title: "Modern Downtown Loft",
            location: "New York City, New York",
            price: 249,
            rating: 4.7,
            reviews: 112,
            image: "/images/property-3.jpg"
        },
        {
            id: 4,
            title: "Seaside Cottage",
            location: "Cape Cod, Massachusetts",
            price: 159,
            rating: 4.8,
            reviews: 87,
            image: "/images/property-4.jpg"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "py-16 px-4 sm:px-6 lg:px-8 bg-gray-50",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-7xl mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "text-center mb-12",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-3xl font-bold text-gray-900",
                            children: "Featured Properties"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mt-4 text-xl text-gray-600",
                            children: "Discover our handpicked selection of exceptional accommodations"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8",
                    children: featuredProperties.map((property)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-white rounded-lg shadow-md overflow-hidden",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "relative h-48",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: property.image,
                                        alt: property.title,
                                        fill: true,
                                        className: "object-cover"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "p-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-lg font-semibold text-gray-900",
                                            children: property.title
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "text-gray-600 flex items-center mt-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(FaMapMarkerAlt, {
                                                    className: "mr-1 text-gray-400"
                                                }),
                                                property.location
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center justify-between mt-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "text-[#2957c3] font-semibold",
                                                    children: [
                                                        "$",
                                                        property.price,
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-gray-500 font-normal",
                                                            children: "/ night"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-yellow-500",
                                                            children: "★"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "ml-1 text-gray-700",
                                                            children: [
                                                                property.rating,
                                                                " (",
                                                                property.reviews,
                                                                ")"
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: `/properties/${property.id}`,
                                            className: "mt-4 block w-full text-center py-2 px-4 border border-transparent rounded-md text-sm font-medium text-white bg-[#2957c3] hover:bg-[#1e3c8a]",
                                            children: "View Details"
                                        })
                                    ]
                                })
                            ]
                        }, property.id))
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mt-12 text-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/search",
                        className: "inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-[#2957c3] hover:bg-[#1e3c8a]",
                        children: "Explore All Properties"
                    })
                })
            ]
        })
    });
};
// How it works section
const HowItWorks = ()=>{
    const steps = [
        {
            id: 1,
            title: "Find the Perfect Stay",
            description: "Search through thousands of listings to find your ideal accommodation.",
            icon: "\uD83D\uDD0D"
        },
        {
            id: 2,
            title: "Book with Confidence",
            description: "Secure your reservation with our safe and easy booking system.",
            icon: "\uD83D\uDCC5"
        },
        {
            id: 3,
            title: "Enjoy Your Experience",
            description: "Arrive and enjoy a comfortable, memorable stay at your chosen property.",
            icon: "\uD83C\uDFE0"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "py-16 px-4 sm:px-6 lg:px-8",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-7xl mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "text-center mb-12",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-3xl font-bold text-gray-900",
                            children: "How It Works"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mt-4 text-xl text-gray-600",
                            children: "Your journey to the perfect stay is just three simple steps away"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 gap-8",
                    children: steps.map((step)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "mx-auto h-16 w-16 flex items-center justify-center rounded-full bg-[#eef2ff] text-3xl",
                                    children: step.icon
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "mt-6 text-xl font-semibold text-gray-900",
                                    children: step.title
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "mt-2 text-gray-600",
                                    children: step.description
                                })
                            ]
                        }, step.id))
                })
            ]
        })
    });
};
// Sara AI Assistant section
const SaraAssistant = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "py-16 px-4 sm:px-6 lg:px-8 bg-[#2957c3] text-white",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "md:w-1/2 mb-8 md:mb-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-3xl font-bold",
                            children: "Meet Sara, Your AI Travel Assistant"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mt-4 text-lg text-blue-100",
                            children: "Sara helps you find the perfect property, answer your questions, and guide you through the booking process."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "mt-6 px-6 py-3 bg-white text-[#2957c3] font-semibold rounded-md hover:bg-gray-100 transition-colors",
                            children: "Chat with Sara"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "md:w-1/2 flex justify-center",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative w-64 h-64 rounded-full bg-blue-700 flex items-center justify-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-6xl",
                                children: "\uD83D\uDC69‍\uD83D\uDCBC"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "absolute -bottom-4 left-0 right-0 mx-auto w-48 bg-white text-[#2957c3] text-center py-2 rounded-full font-semibold",
                                children: "How can I help you?"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
// Investor section
const InvestorSection = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "py-16 px-4 sm:px-6 lg:px-8 bg-gray-900 text-white",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-7xl mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "text-center mb-12",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-3xl font-bold",
                            children: "Invest in Habibistay Properties"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mt-4 text-xl text-gray-300",
                            children: "Earn up to 17% ROI with our curated property investment opportunities"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 md:grid-cols-4 gap-8 text-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-gray-800 p-6 rounded-lg",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-4xl font-bold text-[#FFA726] mb-2",
                                    children: "17%"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-gray-300",
                                    children: "Average ROI"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-gray-800 p-6 rounded-lg",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-4xl font-bold text-[#FFA726] mb-2",
                                    children: "100%"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-gray-300",
                                    children: "End-to-End Management"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-gray-800 p-6 rounded-lg",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-4xl font-bold text-[#FFA726] mb-2",
                                    children: "500+"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-gray-300",
                                    children: "Properties in Portfolio"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-gray-800 p-6 rounded-lg",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-4xl font-bold text-[#FFA726] mb-2",
                                    children: "24/7"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-gray-300",
                                    children: "Transparency & Support"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mt-12 text-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/investor",
                        className: "inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-gray-900 bg-[#FFA726] hover:bg-yellow-500",
                        children: "Learn About Investing"
                    })
                })
            ]
        })
    });
};
function HomePage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout_MainLayout, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(HeroSection, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(FeaturedProperties, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HowItWorks, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(SaraAssistant, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(InvestorSection, {})
        ]
    });
}


/***/ }),

/***/ 14260:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(63296);
module.exports = createProxy("/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/node_modules/next/dist/client/image.js");
 //# sourceMappingURL=image.js.map


/***/ }),

/***/ 6364:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(63296);
module.exports = createProxy("/Users/abdullahmirxa/Downloads/Online-Booking-Management-main/node_modules/next/dist/client/link.js");
 //# sourceMappingURL=link.js.map


/***/ }),

/***/ 14098:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(14260);


/***/ }),

/***/ 83646:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(6364);


/***/ }),

/***/ 33533:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(49472)


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7988,4179,9633,9472,9658,5406,515,9091,153], () => (__webpack_exec__(51448)));
module.exports = __webpack_exports__;

})();