"use strict";
exports.id = 6173;
exports.ids = [6173];
exports.modules = {

/***/ 26173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ usePayments)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sonner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35562);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7641);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_2__);



function usePayments() {
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [payment, setPayment] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [payments, setPayments] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [paymentInit, setPaymentInit] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Initialize a payment for a booking
    const initializePayment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingId, provider)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch("/api/payments", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    bookingId,
                    provider
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to initialize payment");
            }
            const data = await response.json();
            setPaymentInit(data);
            return data;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to initialize payment";
            setError(errorMessage);
            console.error("Error initializing payment:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Complete a payment
    const completePayment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (paymentId, transactionDetails)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`/api/payments/${paymentId}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    operation: "complete",
                    transactionDetails
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to complete payment");
            }
            const updatedPayment = await response.json();
            setPayment(updatedPayment);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.success */ .Am.success("Payment completed successfully");
            return updatedPayment;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to complete payment";
            setError(errorMessage);
            console.error("Error completing payment:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Process a refund
    const refundPayment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (paymentId, amount)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`/api/payments/${paymentId}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    operation: "refund",
                    amount
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to process refund");
            }
            const updatedPayment = await response.json();
            setPayment(updatedPayment);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.success */ .Am.success(amount ? "Partial refund processed successfully" : "Refund processed successfully");
            return updatedPayment;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to process refund";
            setError(errorMessage);
            console.error("Error processing refund:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Get payment details
    const getPayment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (paymentId)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`/api/payments/${paymentId}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to fetch payment details");
            }
            const data = await response.json();
            setPayment(data);
            return data;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to fetch payment details";
            setError(errorMessage);
            console.error("Error fetching payment details:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Get all payments (admin only)
    const getPayments = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (options = {})=>{
        setIsLoading(true);
        setError(null);
        try {
            // Build query parameters
            const params = new URLSearchParams();
            if (options.page) params.append("page", options.page.toString());
            if (options.limit) params.append("limit", options.limit.toString());
            if (options.status) params.append("status", options.status);
            if (options.bookingId) params.append("bookingId", options.bookingId);
            const response = await fetch(`/api/payments?${params.toString()}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to fetch payments");
            }
            const data = await response.json();
            setPayments(data.payments);
            return data;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to fetch payments";
            setError(errorMessage);
            console.error("Error fetching payments:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Get payment status label
    const getPaymentStatusLabel = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((status)=>{
        switch(status){
            case _prisma_client__WEBPACK_IMPORTED_MODULE_2__.PaymentStatus.PENDING:
                return "Pending";
            case _prisma_client__WEBPACK_IMPORTED_MODULE_2__.PaymentStatus.COMPLETED:
                return "Completed";
            case _prisma_client__WEBPACK_IMPORTED_MODULE_2__.PaymentStatus.FAILED:
                return "Failed";
            case _prisma_client__WEBPACK_IMPORTED_MODULE_2__.PaymentStatus.REFUNDED:
                return "Refunded";
            case _prisma_client__WEBPACK_IMPORTED_MODULE_2__.PaymentStatus.PARTIAL_REFUND:
                return "Partially Refunded";
            default:
                return status;
        }
    }, []);
    return {
        isLoading,
        error,
        payment,
        payments,
        paymentInit,
        initializePayment,
        completePayment,
        refundPayment,
        getPayment,
        getPayments,
        getPaymentStatusLabel
    };
}


/***/ })

};
;