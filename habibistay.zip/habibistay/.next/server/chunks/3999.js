"use strict";
exports.id = 3999;
exports.ids = [3999];
exports.modules = {

/***/ 73999:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ useBookings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sonner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35562);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7641);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_2__);



function useBookings() {
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [bookings, setBookings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [currentBooking, setCurrentBooking] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [pagination, setPagination] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        total: 0,
        page: 1,
        limit: 10,
        pages: 0
    });
    // Get all bookings for the current user (or filtered bookings)
    const getBookings = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (options = {})=>{
        setIsLoading(true);
        setError(null);
        try {
            // Build query parameters
            const params = new URLSearchParams();
            if (options.page) params.append("page", options.page.toString());
            if (options.limit) params.append("limit", options.limit.toString());
            if (options.status) params.append("status", options.status);
            if (options.propertyId) params.append("propertyId", options.propertyId);
            const response = await fetch(`/api/bookings?${params.toString()}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to fetch bookings");
            }
            const data = await response.json();
            setBookings(data.bookings);
            setPagination(data.pagination);
            return data;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to fetch bookings";
            setError(errorMessage);
            console.error("Error fetching bookings:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Get a single booking by id
    const getBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingId)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`/api/bookings/${bookingId}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to fetch booking");
            }
            const booking = await response.json();
            setCurrentBooking(booking);
            return booking;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to fetch booking";
            setError(errorMessage);
            console.error("Error fetching booking:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Create a new booking
    const createBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingData)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch("/api/bookings", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(bookingData)
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to create booking");
            }
            const newBooking = await response.json();
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.success */ .Am.success("Booking created successfully");
            return newBooking;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to create booking";
            setError(errorMessage);
            console.error("Error creating booking:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Update a booking
    const updateBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingId, updateData)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`/api/bookings/${bookingId}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(updateData)
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to update booking");
            }
            const updatedBooking = await response.json();
            // Update current booking if it matches
            if (currentBooking?.id === bookingId) {
                setCurrentBooking(updatedBooking);
            }
            // Update bookings list if it contains this booking
            setBookings((prevBookings)=>prevBookings.map((booking)=>booking.id === bookingId ? updatedBooking : booking));
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.success */ .Am.success("Booking updated successfully");
            return updatedBooking;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to update booking";
            setError(errorMessage);
            console.error("Error updating booking:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return null;
        } finally{
            setIsLoading(false);
        }
    }, [
        currentBooking
    ]);
    // Cancel a booking
    const cancelBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingId)=>{
        return updateBooking(bookingId, {
            status: _prisma_client__WEBPACK_IMPORTED_MODULE_2__.BookingStatus.CANCELLED
        });
    }, [
        updateBooking
    ]);
    // Confirm a booking (for hosts)
    const confirmBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingId)=>{
        return updateBooking(bookingId, {
            status: _prisma_client__WEBPACK_IMPORTED_MODULE_2__.BookingStatus.CONFIRMED
        });
    }, [
        updateBooking
    ]);
    // Reject a booking (for hosts)
    const rejectBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingId)=>{
        return updateBooking(bookingId, {
            status: _prisma_client__WEBPACK_IMPORTED_MODULE_2__.BookingStatus.REJECTED
        });
    }, [
        updateBooking
    ]);
    // Complete a booking (for hosts)
    const completeBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingId)=>{
        return updateBooking(bookingId, {
            status: _prisma_client__WEBPACK_IMPORTED_MODULE_2__.BookingStatus.COMPLETED
        });
    }, [
        updateBooking
    ]);
    // Delete a booking (admin only)
    const deleteBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (bookingId)=>{
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`/api/bookings/${bookingId}`, {
                method: "DELETE"
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to delete booking");
            }
            // Remove from bookings list
            setBookings((prevBookings)=>prevBookings.filter((booking)=>booking.id !== bookingId));
            // Clear current booking if it matches
            if (currentBooking?.id === bookingId) {
                setCurrentBooking(null);
            }
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.success */ .Am.success("Booking deleted successfully");
            return true;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to delete booking";
            setError(errorMessage);
            console.error("Error deleting booking:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return false;
        } finally{
            setIsLoading(false);
        }
    }, [
        currentBooking
    ]);
    return {
        isLoading,
        error,
        bookings,
        currentBooking,
        pagination,
        getBookings,
        getBooking,
        createBooking,
        updateBooking,
        cancelBooking,
        confirmBooking,
        rejectBooking,
        completeBooking,
        deleteBooking
    };
}


/***/ })

};
;