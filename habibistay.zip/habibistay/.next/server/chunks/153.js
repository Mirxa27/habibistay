"use strict";
exports.id = 153;
exports.ids = [153];
exports.modules = {

/***/ 153:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout_Navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ../node_modules/next/link.js
var next_link = __webpack_require__(33533);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ../node_modules/next/navigation.js
var navigation = __webpack_require__(52865);
// EXTERNAL MODULE: ../node_modules/next-auth/react.js + 2 modules
var react = __webpack_require__(27258);
// EXTERNAL MODULE: ../node_modules/@prisma/client/default.js
var client_default = __webpack_require__(7641);
// EXTERNAL MODULE: ./src/hooks/useNotifications.ts
var useNotifications = __webpack_require__(89393);
// EXTERNAL MODULE: ../node_modules/date-fns/index.js
var date_fns = __webpack_require__(58525);
;// CONCATENATED MODULE: ./src/components/notifications/NotificationsDropdown.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const NotificationsDropdown = ({ className =""  })=>{
    const [isOpen, setIsOpen] = (0,react_.useState)(false);
    const dropdownRef = (0,react_.useRef)(null);
    const { notifications , unreadCount , isLoading , getNotifications , markAsRead , markAllAsRead , deleteNotification  } = (0,useNotifications/* useNotifications */.z)();
    // Close dropdown when clicking outside
    (0,react_.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);
    // Fetch notifications when dropdown is opened
    (0,react_.useEffect)(()=>{
        if (isOpen) {
            getNotifications({
                limit: 10
            });
        }
    }, [
        isOpen,
        getNotifications
    ]);
    // Initial fetch for unread count
    (0,react_.useEffect)(()=>{
        getNotifications({
            unreadOnly: true,
            limit: 5
        });
    }, [
        getNotifications
    ]);
    // Toggle dropdown
    const toggleDropdown = ()=>{
        setIsOpen(!isOpen);
    };
    // Handle notification click
    const handleNotificationClick = async (notification)=>{
        if (!notification.isRead) {
            await markAsRead(notification.id);
        }
        // Close dropdown after clicking
        setIsOpen(false);
    };
    // Format relative time
    const formatRelativeTime = (dateString)=>{
        const date = new Date(dateString);
        const now = new Date();
        const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
        if (diffInHours < 1) {
            return "Just now";
        } else if (diffInHours < 24) {
            return `${Math.floor(diffInHours)} hour${Math.floor(diffInHours) === 1 ? "" : "s"} ago`;
        } else if (diffInHours < 48) {
            return "Yesterday";
        } else {
            return (0,date_fns.format)(date, "MMM d");
        }
    };
    // Get icon based on notification type
    const getNotificationIcon = (type)=>{
        switch(type){
            case "BOOKING_UPDATE":
                return /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-blue-500",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-calendar-check"
                    })
                });
            case "PAYMENT_UPDATE":
                return /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-green-500",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-money-bill"
                    })
                });
            case "BOOKING_REMINDER":
                return /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-yellow-500",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-bell"
                    })
                });
            case "MESSAGE":
                return /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-purple-500",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-envelope"
                    })
                });
            case "REVIEW":
                return /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-orange-500",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-star"
                    })
                });
            case "SYSTEM":
                return /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-gray-500",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-cog"
                    })
                });
            default:
                return /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-gray-500",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-bell"
                    })
                });
        }
    };
    // Get route based on notification data
    const getNotificationRoute = (notification)=>{
        try {
            const data = notification.data && typeof notification.data === "string" ? JSON.parse(notification.data) : notification.data;
            switch(notification.type){
                case "BOOKING_UPDATE":
                    return `/bookings?bookingId=${data?.bookingId}`;
                case "PAYMENT_UPDATE":
                    return `/bookings?bookingId=${data?.bookingId}`;
                case "BOOKING_REMINDER":
                    return `/bookings?bookingId=${data?.bookingId}`;
                case "MESSAGE":
                    return `/messages`;
                case "REVIEW":
                    return `/properties/${data?.propertyId}`;
                default:
                    return "#";
            }
        } catch (e) {
            return "#";
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `relative ${className}`,
        ref: dropdownRef,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                className: "relative p-2 text-gray-700 hover:text-blue-600 focus:outline-none",
                onClick: toggleDropdown,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-bell text-xl"
                    }),
                    unreadCount > 0 && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "absolute top-0 right-0 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center",
                        children: unreadCount > 9 ? "9+" : unreadCount
                    })
                ]
            }),
            isOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute right-0 mt-2 w-80 max-h-96 overflow-y-auto bg-white rounded-md shadow-lg z-50",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-3 border-b border-gray-100 flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "font-semibold text-gray-900",
                                children: "Notifications"
                            }),
                            unreadCount > 0 && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "text-xs text-blue-600 hover:text-blue-800",
                                onClick: markAllAsRead,
                                children: "Mark all as read"
                            })
                        ]
                    }),
                    isLoading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "p-4 text-center text-gray-500",
                        children: "Loading..."
                    }) : notifications.length === 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "p-4 text-center text-gray-500",
                        children: "No notifications yet"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "divide-y divide-gray-100",
                        children: notifications.map((notification)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: `p-3 hover:bg-gray-50 flex items-start ${!notification.isRead ? "bg-blue-50" : ""}`,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex-shrink-0 mt-1 mr-3 text-lg w-8 text-center",
                                        children: getNotificationIcon(notification.type)
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex-grow min-w-0",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: getNotificationRoute(notification),
                                            className: "block",
                                            onClick: ()=>handleNotificationClick(notification),
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-sm font-medium text-gray-900 truncate",
                                                    children: notification.title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-xs text-gray-500 line-clamp-2",
                                                    children: notification.message
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-xs text-gray-400 mt-1",
                                                    children: formatRelativeTime(notification.createdAt)
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: ()=>deleteNotification(notification.id),
                                        className: "ml-2 text-gray-400 hover:text-gray-600",
                                        "aria-label": "Delete notification",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fa-solid fa-times"
                                        })
                                    })
                                ]
                            }, notification.id))
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "p-2 border-t border-gray-100 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/notifications",
                            className: "text-xs text-blue-600 hover:text-blue-800",
                            onClick: ()=>setIsOpen(false),
                            children: "View all notifications"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const notifications_NotificationsDropdown = (NotificationsDropdown);

;// CONCATENATED MODULE: ./src/components/layout/Navbar.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






// Placeholder icon components 
const IconComponent = ({ className , children  })=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: `inline-block ${className || ""}`,
        style: {
            width: "1em",
            height: "1em"
        },
        children: children
    });
const FaUserCircle = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDC64"
    });
const FaSignOutAlt = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDEAA"
    });
const FaCalendarAlt = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDCC5"
    });
const FaEnvelope = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDCE7"
    });
const FaCog = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "⚙️"
    });
const FaBell = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "\uD83D\uDD14"
    });
const FaQuestionCircle = ({ className  })=>/*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {
        className: className,
        children: "❓"
    });
const Navbar = ()=>{
    const { data: session , status  } = (0,react/* useSession */.kP)();
    const pathname = (0,navigation.usePathname)();
    const [isMenuOpen, setIsMenuOpen] = (0,react_.useState)(false);
    const [isProfileMenuOpen, setIsProfileMenuOpen] = (0,react_.useState)(false);
    const isActive = (path)=>pathname === path;
    const toggleMenu = ()=>setIsMenuOpen(!isMenuOpen);
    const toggleProfileMenu = ()=>setIsProfileMenuOpen(!isProfileMenuOpen);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "bg-white shadow-md",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between h-16",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex-shrink-0 flex items-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        className: "text-2xl font-bold text-[#2957c3]",
                                        children: "Habibistay"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "hidden sm:ml-6 sm:flex sm:space-x-8",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            className: `${isActive("/") ? "border-[#2957c3] text-gray-900" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"} inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`,
                                            children: "Home"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/search",
                                            className: `${isActive("/search") ? "border-[#2957c3] text-gray-900" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"} inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`,
                                            children: "Search"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/help",
                                            className: `${isActive("/help") ? "border-[#2957c3] text-gray-900" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"} inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`,
                                            children: "Help"
                                        }),
                                        session?.user.role === client_default.UserRole.HOST && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/host/properties",
                                            className: `${pathname?.startsWith("/host") ? "border-[#2957c3] text-gray-900" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"} inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`,
                                            children: "My Properties"
                                        }),
                                        session?.user.role === client_default.UserRole.PROPERTY_MANAGER && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/manager/properties",
                                            className: `${pathname?.startsWith("/manager") ? "border-[#2957c3] text-gray-900" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"} inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`,
                                            children: "Managed Properties"
                                        }),
                                        session?.user.role === client_default.UserRole.ADMIN && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/admin/dashboard",
                                            className: `${pathname?.startsWith("/admin") ? "border-[#2957c3] text-gray-900" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"} inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`,
                                            children: "Admin"
                                        }),
                                        session?.user.role === client_default.UserRole.INVESTOR && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/investor/dashboard",
                                            className: `${pathname?.startsWith("/investor") ? "border-[#2957c3] text-gray-900" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"} inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`,
                                            children: "Investments"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "hidden sm:ml-6 sm:flex sm:items-center",
                            children: status === "authenticated" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(notifications_NotificationsDropdown, {
                                        className: "mr-4"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "ml-3 relative",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: toggleProfileMenu,
                                                    className: "bg-white flex text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2957c3]",
                                                    id: "user-menu-button",
                                                    "aria-expanded": "false",
                                                    "aria-haspopup": "true",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "sr-only",
                                                            children: "Open user menu"
                                                        }),
                                                        session.user.image ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            className: "h-8 w-8 rounded-full",
                                                            src: session.user.image,
                                                            alt: session.user.name || "User"
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx(FaUserCircle, {
                                                            className: "h-8 w-8 text-gray-400"
                                                        })
                                                    ]
                                                })
                                            }),
                                            isProfileMenuOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-10",
                                                role: "menu",
                                                "aria-orientation": "vertical",
                                                "aria-labelledby": "user-menu-button",
                                                tabIndex: -1,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "px-4 py-2 text-xs text-gray-500",
                                                        children: [
                                                            "Signed in as ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "font-medium",
                                                                children: session.user.email
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "border-t border-gray-100"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/profile",
                                                        className: "block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100",
                                                        role: "menuitem",
                                                        tabIndex: -1,
                                                        id: "user-menu-item-0",
                                                        onClick: ()=>setIsProfileMenuOpen(false),
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(FaUserCircle, {
                                                                    className: "mr-2"
                                                                }),
                                                                " Profile"
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/bookings",
                                                        className: "block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100",
                                                        role: "menuitem",
                                                        tabIndex: -1,
                                                        id: "user-menu-item-1",
                                                        onClick: ()=>setIsProfileMenuOpen(false),
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(FaCalendarAlt, {
                                                                    className: "mr-2"
                                                                }),
                                                                " My Bookings"
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/messages",
                                                        className: "block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100",
                                                        role: "menuitem",
                                                        tabIndex: -1,
                                                        id: "user-menu-item-2",
                                                        onClick: ()=>setIsProfileMenuOpen(false),
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(FaEnvelope, {
                                                                    className: "mr-2"
                                                                }),
                                                                " Messages"
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/settings",
                                                        className: "block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100",
                                                        role: "menuitem",
                                                        tabIndex: -1,
                                                        id: "user-menu-item-3",
                                                        onClick: ()=>setIsProfileMenuOpen(false),
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(FaCog, {
                                                                    className: "mr-2"
                                                                }),
                                                                " Settings"
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/notifications",
                                                        className: "block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100",
                                                        role: "menuitem",
                                                        tabIndex: -1,
                                                        id: "user-menu-item-4",
                                                        onClick: ()=>setIsProfileMenuOpen(false),
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(FaBell, {
                                                                    className: "mr-2"
                                                                }),
                                                                " Notifications"
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "border-t border-gray-100"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        onClick: ()=>(0,react/* signOut */.w7)({
                                                                callbackUrl: "/"
                                                            }),
                                                        className: "block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100",
                                                        role: "menuitem",
                                                        tabIndex: -1,
                                                        id: "user-menu-item-4",
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(FaSignOutAlt, {
                                                                    className: "mr-2"
                                                                }),
                                                                " Sign out"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex space-x-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/login",
                                        className: "text-gray-500 hover:text-gray-700 px-3 py-2 rounded-md text-sm font-medium",
                                        children: "Sign in"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/register",
                                        className: "bg-[#2957c3] text-white hover:bg-[#1e3c8a] px-3 py-2 rounded-md text-sm font-medium",
                                        children: "Sign up"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "-mr-2 flex items-center sm:hidden",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                onClick: toggleMenu,
                                type: "button",
                                className: "inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#2957c3]",
                                "aria-controls": "mobile-menu",
                                "aria-expanded": "false",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "sr-only",
                                        children: "Open main menu"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        className: `${isMenuOpen ? "hidden" : "block"} h-6 w-6`,
                                        xmlns: "http://www.w3.org/2000/svg",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        "aria-hidden": "true",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: "2",
                                            d: "M4 6h16M4 12h16M4 18h16"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        className: `${isMenuOpen ? "block" : "hidden"} h-6 w-6`,
                                        xmlns: "http://www.w3.org/2000/svg",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        "aria-hidden": "true",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: "2",
                                            d: "M6 18L18 6M6 6l12 12"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${isMenuOpen ? "block" : "hidden"} sm:hidden`,
                id: "mobile-menu",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pt-2 pb-3 space-y-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                className: `${isActive("/") ? "bg-[#eef2ff] border-[#2957c3] text-[#2957c3]" : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"} block pl-3 pr-4 py-2 border-l-4 text-base font-medium`,
                                onClick: toggleMenu,
                                children: "Home"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/search",
                                className: `${isActive("/search") ? "bg-[#eef2ff] border-[#2957c3] text-[#2957c3]" : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"} block pl-3 pr-4 py-2 border-l-4 text-base font-medium`,
                                onClick: toggleMenu,
                                children: "Search"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/help",
                                className: `${isActive("/help") ? "bg-[#eef2ff] border-[#2957c3] text-[#2957c3]" : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"} block pl-3 pr-4 py-2 border-l-4 text-base font-medium`,
                                onClick: toggleMenu,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(FaQuestionCircle, {
                                            className: "mr-2"
                                        }),
                                        " Help"
                                    ]
                                })
                            }),
                            session?.user.role === client_default.UserRole.HOST && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/host/properties",
                                className: `${pathname?.startsWith("/host") ? "bg-[#eef2ff] border-[#2957c3] text-[#2957c3]" : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"} block pl-3 pr-4 py-2 border-l-4 text-base font-medium`,
                                onClick: toggleMenu,
                                children: "My Properties"
                            }),
                            session?.user.role === client_default.UserRole.PROPERTY_MANAGER && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/manager/properties",
                                className: `${pathname?.startsWith("/manager") ? "bg-[#eef2ff] border-[#2957c3] text-[#2957c3]" : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"} block pl-3 pr-4 py-2 border-l-4 text-base font-medium`,
                                onClick: toggleMenu,
                                children: "Managed Properties"
                            }),
                            session?.user.role === client_default.UserRole.ADMIN && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/admin/dashboard",
                                className: `${pathname?.startsWith("/admin") ? "bg-[#eef2ff] border-[#2957c3] text-[#2957c3]" : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"} block pl-3 pr-4 py-2 border-l-4 text-base font-medium`,
                                onClick: toggleMenu,
                                children: "Admin"
                            }),
                            session?.user.role === client_default.UserRole.INVESTOR && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/investor/dashboard",
                                className: `${pathname?.startsWith("/investor") ? "bg-[#eef2ff] border-[#2957c3] text-[#2957c3]" : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"} block pl-3 pr-4 py-2 border-l-4 text-base font-medium`,
                                onClick: toggleMenu,
                                children: "Investments"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "pt-4 pb-3 border-t border-gray-200",
                        children: status === "authenticated" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center px-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex-shrink-0",
                                            children: session.user.image ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                className: "h-10 w-10 rounded-full",
                                                src: session.user.image,
                                                alt: session.user.name || "User"
                                            }) : /*#__PURE__*/ jsx_runtime_.jsx(FaUserCircle, {
                                                className: "h-10 w-10 text-gray-400"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-base font-medium text-gray-800",
                                                    children: session.user.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-sm font-medium text-gray-500",
                                                    children: session.user.email
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/notifications",
                                            className: "ml-auto",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(FaBell, {
                                                className: "h-6 w-6 text-gray-400"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-3 space-y-1",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/profile",
                                            className: "block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100",
                                            onClick: toggleMenu,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(FaUserCircle, {
                                                        className: "mr-2"
                                                    }),
                                                    " Profile"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/bookings",
                                            className: "block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100",
                                            onClick: toggleMenu,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(FaCalendarAlt, {
                                                        className: "mr-2"
                                                    }),
                                                    " My Bookings"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/messages",
                                            className: "block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100",
                                            onClick: toggleMenu,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(FaEnvelope, {
                                                        className: "mr-2"
                                                    }),
                                                    " Messages"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/notifications",
                                            className: "block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100",
                                            onClick: toggleMenu,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(FaBell, {
                                                        className: "mr-2"
                                                    }),
                                                    " Notifications"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/settings",
                                            className: "block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100",
                                            onClick: toggleMenu,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(FaCog, {
                                                        className: "mr-2"
                                                    }),
                                                    " Settings"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            onClick: ()=>(0,react/* signOut */.w7)({
                                                    callbackUrl: "/"
                                                }),
                                            className: "block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(FaSignOutAlt, {
                                                        className: "mr-2"
                                                    }),
                                                    " Sign out"
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-3 space-y-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/login",
                                    className: "block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100",
                                    onClick: toggleMenu,
                                    children: "Sign in"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/register",
                                    className: "block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100",
                                    onClick: toggleMenu,
                                    children: "Sign up"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layout_Navbar = (Navbar);


/***/ }),

/***/ 89393:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ useNotifications)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sonner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35562);


function useNotifications() {
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [notifications, setNotifications] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [unreadCount, setUnreadCount] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const [pagination, setPagination] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        total: 0,
        page: 1,
        limit: 20,
        pages: 0
    });
    // Parse the data field of notifications if it's a string
    const parseNotificationData = (notification)=>{
        if (notification.data && typeof notification.data === "string") {
            try {
                return {
                    ...notification,
                    data: JSON.parse(notification.data)
                };
            } catch (e) {
                // If parsing fails, just return the original
                return notification;
            }
        }
        return notification;
    };
    // Get all notifications for the current user
    const getNotifications = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (options = {})=>{
        setIsLoading(true);
        setError(null);
        try {
            // Build query parameters
            const params = new URLSearchParams();
            if (options.page) params.append("page", options.page.toString());
            if (options.limit) params.append("limit", options.limit.toString());
            if (options.unreadOnly) params.append("unreadOnly", "true");
            const response = await fetch(`/api/notifications?${params.toString()}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to fetch notifications");
            }
            const data = await response.json();
            // Parse notification data JSON strings
            const parsedNotifications = data.notifications.map(parseNotificationData);
            setNotifications(parsedNotifications);
            setPagination(data.pagination);
            // Update unread count
            setUnreadCount(parsedNotifications.filter((n)=>!n.isRead).length);
            return parsedNotifications;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to fetch notifications";
            setError(errorMessage);
            console.error("Error fetching notifications:", error);
            return [];
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Get unread count
    const getUnreadCount = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async ()=>{
        try {
            const response = await fetch("/api/notifications?unreadOnly=true&limit=1");
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to fetch unread count");
            }
            const data = await response.json();
            setUnreadCount(data.pagination.total);
            return data.pagination.total;
        } catch (error) {
            console.error("Error fetching unread count:", error);
            return 0;
        }
    }, []);
    // Mark a notification as read
    const markAsRead = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (notificationId)=>{
        setIsLoading(true);
        try {
            const response = await fetch(`/api/notifications/${notificationId}`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    isRead: true
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to mark notification as read");
            }
            // Update local state
            setNotifications((prevNotifications)=>prevNotifications.map((notification)=>notification.id === notificationId ? {
                        ...notification,
                        isRead: true
                    } : notification));
            // Update unread count
            setUnreadCount((prevCount)=>Math.max(0, prevCount - 1));
            return true;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to mark notification as read";
            setError(errorMessage);
            console.error("Error marking notification as read:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return false;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Mark all notifications as read
    const markAllAsRead = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async ()=>{
        setIsLoading(true);
        try {
            // Get all unread notifications
            const unreadNotifications = await getNotifications({
                unreadOnly: true,
                limit: 100
            });
            // Mark each as read
            const promises = unreadNotifications.map((notification)=>fetch(`/api/notifications/${notification.id}`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        isRead: true
                    })
                }));
            await Promise.all(promises);
            // Update local state
            setNotifications((prevNotifications)=>prevNotifications.map((notification)=>({
                        ...notification,
                        isRead: true
                    })));
            // Update unread count
            setUnreadCount(0);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.success */ .Am.success("All notifications marked as read");
            return true;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to mark all notifications as read";
            setError(errorMessage);
            console.error("Error marking all notifications as read:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return false;
        } finally{
            setIsLoading(false);
        }
    }, [
        getNotifications
    ]);
    // Delete a notification
    const deleteNotification = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (notificationId)=>{
        setIsLoading(true);
        try {
            const response = await fetch(`/api/notifications/${notificationId}`, {
                method: "DELETE"
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to delete notification");
            }
            // Update local state
            const deletedNotification = notifications.find((n)=>n.id === notificationId);
            setNotifications((prevNotifications)=>prevNotifications.filter((notification)=>notification.id !== notificationId));
            // Update unread count if the deleted notification was unread
            if (deletedNotification && !deletedNotification.isRead) {
                setUnreadCount((prevCount)=>Math.max(0, prevCount - 1));
            }
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.success */ .Am.success("Notification deleted");
            return true;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Failed to delete notification";
            setError(errorMessage);
            console.error("Error deleting notification:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(errorMessage);
            return false;
        } finally{
            setIsLoading(false);
        }
    }, [
        notifications
    ]);
    return {
        isLoading,
        error,
        notifications,
        unreadCount,
        pagination,
        getNotifications,
        getUnreadCount,
        markAsRead,
        markAllAsRead,
        deleteNotification
    };
}


/***/ })

};
;