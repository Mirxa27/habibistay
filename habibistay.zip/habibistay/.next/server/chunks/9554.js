"use strict";
exports.id = 9554;
exports.ids = [9554];
exports.modules = {

/***/ 29554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ usePropertyAvailability)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sonner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35562);


function usePropertyAvailability() {
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [availability, setAvailability] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [basePrice, setBasePrice] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    // Get availability for a specific date range
    const getAvailability = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (propertyId, startDate, endDate)=>{
        setIsLoading(true);
        try {
            const response = await fetch(`/api/properties/${propertyId}/availability?startDate=${startDate}&endDate=${endDate}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json"
                }
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to fetch availability");
            }
            const data = await response.json();
            setAvailability(data.availability);
            setBasePrice(data.basePrice);
            return data;
        } catch (error) {
            console.error("Error fetching availability:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(error instanceof Error ? error.message : "Failed to fetch availability");
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Update availability for specific dates
    const updateAvailability = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (propertyId, dates)=>{
        setIsLoading(true);
        try {
            const response = await fetch(`/api/properties/${propertyId}/availability`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    dates
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Failed to update availability");
            }
            const data = await response.json();
            // Check if there were any errors
            const errors = data.results.filter((result)=>result.status === "error");
            if (errors.length > 0) {
                // Some dates failed to update
                sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.warning */ .Am.warning(`${errors.length} dates could not be updated`);
            } else {
                sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.success */ .Am.success("Availability updated successfully");
            }
            return data;
        } catch (error) {
            console.error("Error updating availability:", error);
            sonner__WEBPACK_IMPORTED_MODULE_1__/* .toast.error */ .Am.error(error instanceof Error ? error.message : "Failed to update availability");
            return null;
        } finally{
            setIsLoading(false);
        }
    }, []);
    // Check if a specific date range is available
    const checkAvailabilityForBooking = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (propertyId, checkInDate, checkOutDate)=>{
        try {
            const data = await getAvailability(propertyId, checkInDate, checkOutDate);
            if (!data) {
                return {
                    isAvailable: false,
                    unavailableDates: []
                };
            }
            const unavailableDates = data.availability.filter((day)=>!day.isAvailable || day.isBooked).map((day)=>day.date);
            return {
                isAvailable: unavailableDates.length === 0,
                unavailableDates
            };
        } catch (error) {
            console.error("Error checking availability for booking:", error);
            return {
                isAvailable: false,
                unavailableDates: []
            };
        }
    }, [
        getAvailability
    ]);
    // Calculate the total price for a booking
    const calculateBookingPrice = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((checkInDateString, checkOutDateString, availabilityData = null)=>{
        try {
            const checkInDate = new Date(checkInDateString);
            const checkOutDate = new Date(checkOutDateString);
            // Calculate nights
            const diffTime = Math.abs(checkOutDate.getTime() - checkInDate.getTime());
            const totalNights = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            if (isNaN(totalNights) || totalNights <= 0) {
                return {
                    totalNights: 0,
                    priceBreakdown: [],
                    totalPrice: 0
                };
            }
            const data = availabilityData || availability;
            let priceBreakdown = [];
            // If we have availability data, calculate price from custom prices
            if (data && data.length > 0) {
                // Create a map of date -> price for easier lookup
                const priceMap = new Map();
                data.forEach((day)=>{
                    priceMap.set(day.date, day.price);
                });
                // Calculate price for each night of the stay
                const currentDate = new Date(checkInDate);
                while(currentDate < checkOutDate){
                    const dateString = currentDate.toISOString().split("T")[0];
                    const price = priceMap.get(dateString) || basePrice;
                    priceBreakdown.push({
                        date: dateString,
                        price
                    });
                    // Move to next day
                    currentDate.setDate(currentDate.getDate() + 1);
                }
            } else {
                // No availability data, just use base price
                const currentDate = new Date(checkInDate);
                while(currentDate < checkOutDate){
                    const dateString = currentDate.toISOString().split("T")[0];
                    priceBreakdown.push({
                        date: dateString,
                        price: basePrice
                    });
                    // Move to next day
                    currentDate.setDate(currentDate.getDate() + 1);
                }
            }
            // Calculate total price
            const totalPrice = priceBreakdown.reduce((total, day)=>total + day.price, 0);
            return {
                totalNights,
                priceBreakdown,
                totalPrice
            };
        } catch (error) {
            console.error("Error calculating booking price:", error);
            return {
                totalNights: 0,
                priceBreakdown: [],
                totalPrice: 0
            };
        }
    }, [
        availability,
        basePrice
    ]);
    return {
        isLoading,
        availability,
        basePrice,
        getAvailability,
        updateAvailability,
        checkAvailabilityForBooking,
        calculateBookingPrice
    };
}


/***/ })

};
;